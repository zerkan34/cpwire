/* theme.css — identité visuelle reprise du document portefeuille Armonie. */
:root {
  --indigo: #3a3658;
  --indigo-deep: #2c2945;
  --purple: #6e5cc4;
  --purple-strong: #5a48b0;
  --purple-soft: #efecfb;
  --purple-line: #cfc6f2;
  --gold: #c7a14a;
  --hd-grad: linear-gradient(135deg, var(--indigo-deep), var(--indigo) 55%, #46426c);
  --gold-deep: #a9842f;
  --orange: #fb7a28;
  --orange-deep: #e0600f;
  --orange-soft: #fff2e7;
  /* Dégradé de la marque « WIRE » du logo : orange → bleu lavande (relevé sur cpwire-logo.png) */
  --wire-grad: linear-gradient(90deg, #fc6f28 0%, #ff8a2a 20%, #fe9424 40%, #e7b293 62%, #bfc4ea 82%, #cbdcff 100%);
  --ink: #2a2937;
  --body: #3d3b4d;
  --muted: #74718a;
  --line: #e7e5f1;
  --line-soft: #f0eef7;
  --row-alt: #f6f5fb;
  --bg: #f4f3f8;
  --card: #ffffff;
  --green: #1f8a5f;
  --green-bg: #e2f3ea;
  --blue: #2f5fa8;
  --blue-bg: #e6effb;
  --amber: #b07423;
  --amber-bg: #fbf0e2;
  --red: #c0392b;
  --red-bg: #fbe6e3;
  --shadow: 0 1px 3px rgba(38, 35, 64, 0.06), 0 8px 28px rgba(38, 35, 64, 0.07);
  --shadow-lg: 0 18px 50px rgba(38, 35, 64, 0.16);
}
* { box-sizing: border-box; }
html { -webkit-text-size-adjust: 100%; }
body {
  margin: 0;
  background: var(--bg);
  color: var(--body);
  font-family: "Inter", system-ui, -apple-system, sans-serif;
  font-size: 15px;
  line-height: 1.5;
}
a { color: inherit; }
.wrap { max-width: 1180px; margin: 0 auto; padding: 26px 24px 60px; }

/* ---- En-tête ---- */
.hdr {
  background: var(--hd-grad);
  color: #fff; border-radius: 22px; padding: 26px 30px; box-shadow: var(--shadow-lg);
  position: relative; overflow: hidden;
}
.hdr:before {
  content: ""; position: absolute; right: -70px; top: -70px; width: 240px; height: 240px;
  border-radius: 50%; background: radial-gradient(circle, rgba(199, 161, 74, 0.2), transparent 70%);
}
.hdr-row { display: flex; align-items: flex-start; justify-content: space-between; gap: 20px; flex-wrap: wrap; position: relative; }
.eyebrow { display: block; width: 100%; text-align: right; font-weight: 700; font-size: 10.5px; letter-spacing: 0.12em; text-transform: uppercase; color: var(--gold); }
.hdr h1 { font-family: inherit; font-weight: 700; text-transform: uppercase; letter-spacing: 0.12em; font-size: 22px; color: #fff; margin: 10px 0 0; line-height: 1.15; }
.hdr .sub { color: rgba(255, 255, 255, 0.75); font-size: 14px; max-width: 560px; }
.hdr-actions { display: flex; flex-direction: column; align-items: flex-end; gap: 8px; }
.btn {
  font-family: "Inter"; font-weight: 600; font-size: 13px; cursor: pointer; border: 0;
  border-radius: 10px; padding: 10px 16px; display: inline-flex; align-items: center; gap: 8px;
  transition: transform 0.12s ease, filter 0.12s ease;
}
.btn:hover { filter: brightness(1.06); transform: translateY(-1px); }
.btn.gold { background: var(--orange); color: #fff; }
.btn.gold:hover { background: var(--orange-deep); }
.btn.ghost { background: rgba(255, 255, 255, 0.12); color: #fff; border: 1px solid rgba(255, 255, 255, 0.22); }
.src { font-size: 11.5px; color: rgba(255, 255, 255, 0.62); }

/* ---- KPI ---- */
.kpis { display: grid; grid-template-columns: repeat(6, 1fr); gap: 12px; margin-top: 22px; position: relative; }
.kpi { background: rgba(255, 255, 255, 0.08); border: 1px solid rgba(255, 255, 255, 0.14); border-radius: 13px; padding: 13px 14px; }
.kpi .lbl { font-weight: 600; font-size: 10.5px; letter-spacing: 0.07em; text-transform: uppercase; color: rgba(255, 255, 255, 0.66); }
.kpi .val { font-family: "Poppins"; font-weight: 800; font-size: 28px; line-height: 1.05; margin-top: 5px; color: #fff; }
.kpi.todo .val { color: #ffd5a8; }
.kpi.prog .val { color: #a8c8ff; }
.kpi.block .val { color: #ffb1a6; }
.kpi.done .val { color: #a6e7c8; }
.kpi.late .val { color: #ff9d8e; }
.progress { margin-top: 18px; display: flex; align-items: center; gap: 12px; font-size: 13px; color: rgba(255, 255, 255, 0.85); position: relative; }
.bar { flex: 1; height: 11px; border-radius: 99px; background: rgba(255, 255, 255, 0.16); overflow: hidden; }
.bar > span { display: block; height: 100%; border-radius: 99px; background: linear-gradient(90deg, #6ed0a8, #37b07f); transition: width 0.4s ease; }

/* ---- En-tête : barre recherche + actions alignées (même ligne que Actualiser) ---- */
.hdr-left { min-width: 0; }
.hdr-bar { display: flex; gap: 8px; align-items: center; justify-content: flex-end; flex-wrap: wrap; }
.hdr-bar .btn { height: 40px; }
.hdr-search { position: relative; width: 280px; }
.hdr-search input { width: 100%; height: 40px; border: 1px solid rgba(255,255,255,.2); background: rgba(255,255,255,.97); border-radius: 10px; padding: 0 34px; font-size: 13.5px; color: var(--body); }
.hdr-search input:focus { outline: 2px solid rgba(255,255,255,.55); }
.hs-ic { position: absolute; left: 11px; top: 50%; transform: translateY(-50%); font-size: 13px; opacity: .55; pointer-events: none; }
.hs-x { position: absolute; right: 6px; top: 50%; transform: translateY(-50%); border: 0; background: none; cursor: pointer; font-size: 18px; line-height: 1; color: var(--muted); padding: 4px 6px; }
.hs-x:hover { color: var(--ink); }
.btn.bell { position: relative; }
.bell-badge { position: absolute; top: -7px; right: -7px; min-width: 19px; height: 19px; padding: 0 5px; border-radius: 99px; background: var(--red); color: #fff; font-size: 11px; font-weight: 700; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 0 2px var(--indigo-deep); }

/* ---- Jauge dans le bouton Actualiser ---- */
.gauge-btn { position: relative; overflow: hidden; min-width: 138px; }
/* Bouton « Actualiser » : même dégradé que « WIRE » */
.btn.gold.gauge-btn { background: var(--wire-grad); color: #fff; }
.btn.gold.gauge-btn:hover { background: var(--wire-grad); filter: brightness(1.05); }
.gauge-fill { position: absolute; left: 0; top: 0; bottom: 0; width: 0; background: rgba(34, 26, 70, .28); transition: width .35s ease; z-index: 0; }
.gauge-label { position: relative; z-index: 1; text-shadow: 0 1px 2px rgba(25, 20, 50, .45); }

/* ---- Bouton cloche (notifications) ---- */
.btn.bell { padding-left: 12px; padding-right: 12px; }
.btn.bell.on { background: var(--orange); color: #fff; border-color: var(--orange); }

/* ---- Bouton remonter en haut ---- */
.to-top { position: fixed; left: 16px; z-index: 95; bottom: calc(16px + env(safe-area-inset-bottom, 0px)); width: 44px; height: 44px; border-radius: 50%; border: 0; background: var(--indigo); color: #fff; font-size: 20px; cursor: pointer; box-shadow: 0 10px 26px rgba(44,41,69,.32); animation: toast-in .2s ease-out; }
.to-top:hover { background: var(--indigo-deep); }

/* ---- Nom de développeur (récap, tables) cliquable + supprimé ---- */
.dev-chip { display: inline-flex; align-items: center; gap: 4px; font-weight: 700; font-size: 12px; color: var(--orange-deep); background: var(--orange-soft); border: 1px solid #f6d8be; border-radius: 99px; padding: 2px 10px; cursor: pointer; white-space: nowrap; }
.dev-chip:hover { background: var(--orange); color: #fff; border-color: var(--orange); }
.dev-chip.del { color: var(--muted); background: var(--line-soft); border-color: var(--line); text-decoration: line-through; }
.dev-del-tag { font-size: 10px; font-weight: 600; color: var(--muted); margin-left: 4px; font-style: italic; }
.dev-row.del .dname { color: var(--muted); text-decoration: line-through; opacity: .75; }

/* ---- Esthétique tickets (tableau cockpit) ---- */
tbody tr { transition: background .12s ease; }
tbody tr:hover td { background: var(--purple-soft); }
tr.mine td:first-child { box-shadow: inset 3px 0 0 var(--gold-deep); }
tr.has-flag td:first-child { box-shadow: inset 3px 0 0 var(--orange); }
.prio-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 7px; vertical-align: middle; background: var(--line); }
.prio-dot.p-haute, .prio-dot.p-highest, .prio-dot.p-high { background: var(--red); }
.prio-dot.p-moyenne, .prio-dot.p-medium { background: var(--amber); }
.prio-dot.p-basse, .prio-dot.p-low, .prio-dot.p-lowest { background: var(--blue); }
.assignee-link { cursor: pointer; border-bottom: 1px dotted var(--purple-line); }
.assignee-link:hover { color: var(--purple-strong); }

/* ---- Sections ---- */
.section-title { font-family: "Poppins"; font-weight: 700; font-size: 19px; color: var(--ink); margin: 30px 0 14px; display: flex; align-items: center; gap: 11px; }
.section-title:before { content: ""; width: 11px; height: 26px; border-radius: 5px; background: linear-gradient(var(--purple), var(--purple-strong)); }

/* ---- Cartes projet ---- */
.cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; }
.pcard { background: var(--card); border: 1px solid var(--line); border-radius: 16px; padding: 18px 20px; box-shadow: var(--shadow); cursor: pointer; transition: transform 0.12s ease, box-shadow 0.15s ease, border-color 0.15s ease; }
.pcard:hover { transform: translateY(-2px); box-shadow: var(--shadow-lg); border-color: var(--purple-line); }
.pcard.active { border-color: var(--purple); box-shadow: 0 0 0 2px var(--purple-soft), var(--shadow); }
.pcard h3 { font-family: "Poppins"; font-weight: 700; font-size: 17px; color: var(--ink); margin: 0 0 4px; }
.pcard .meta { font-size: 12px; color: var(--muted); margin-bottom: 12px; }
.pcard .pbar { height: 9px; border-radius: 99px; background: var(--line); overflow: hidden; margin-bottom: 12px; }
.pcard .pbar > span { display: block; height: 100%; background: linear-gradient(90deg, #6ed0a8, #37b07f); }
.pcard .stats { display: flex; flex-wrap: wrap; gap: 8px; }
.dot { display: inline-flex; align-items: center; gap: 5px; font-size: 12px; font-weight: 600; }
.dot:before { content: ""; width: 8px; height: 8px; border-radius: 50%; }
.dot.todo:before { background: var(--amber); } .dot.todo { color: var(--amber); }
.dot.prog:before { background: var(--blue); } .dot.prog { color: var(--blue); }
.dot.block:before { background: var(--red); } .dot.block { color: var(--red); }
.dot.done:before { background: var(--green); } .dot.done { color: var(--green); }
.health { float: right; font-size: 11px; font-weight: 700; padding: 3px 9px; border-radius: 99px; }
.health.green { background: var(--green-bg); color: var(--green); }
.health.amber { background: var(--amber-bg); color: var(--amber); }
.health.red { background: var(--red-bg); color: var(--red); }

/* ---- Filtres + table ---- */
.panel { background: var(--card); border: 1px solid var(--line); border-radius: 16px; padding: 18px 20px; box-shadow: var(--shadow); }
.filters { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin-bottom: 10px; }
.fg-lbl { font-weight: 700; font-size: 11px; letter-spacing: 0.07em; text-transform: uppercase; color: var(--muted); margin-right: 2px; }
.fbtn { font-weight: 600; font-size: 12.5px; cursor: pointer; border: 1px solid var(--line); background: #fff; color: var(--body); border-radius: 99px; padding: 6px 13px; transition: all 0.12s ease; }
.fbtn:hover { border-color: var(--purple); }
.fbtn.active { background: var(--purple); border-color: var(--purple); color: #fff; }
.fbtn .cnt { opacity: 0.65; font-weight: 500; margin-left: 5px; }

/* Recherche + sélecteurs de filtre */
.search-row { position: relative; display: flex; align-items: center; margin-bottom: 12px; }
.search-ic { position: absolute; left: 12px; font-size: 14px; opacity: .6; pointer-events: none; }
.search-input { width: 100%; border: 1px solid var(--line); border-radius: 10px; padding: 10px 36px; font-size: 14px; color: var(--body); }
.search-input:focus { outline: 2px solid var(--purple-soft); border-color: var(--purple); }
.search-x { position: absolute; right: 8px; border: 0; background: none; cursor: pointer; font-size: 18px; line-height: 1; color: var(--muted); padding: 4px 8px; }
.search-x:hover { color: var(--purple-strong); }
.fselect { border: 1px solid var(--line); background: #fff; color: var(--body); border-radius: 99px; padding: 6px 12px; font-size: 12.5px; font-weight: 600; cursor: pointer; }
.fselect:focus { outline: 2px solid var(--purple-soft); border-color: var(--purple); }
.fbtn.reset { border-color: #e7c4c4; color: #b4434a; }
.fbtn.reset:hover { border-color: #b4434a; }
.btn-line.sm { font-size: 12px; padding: 5px 11px; border-radius: 8px; }
.btn-solid.sm { font-size: 12px; padding: 5px 11px; border-radius: 8px; font-weight: 600; }

/* Tri par colonne */
.th-sort { cursor: pointer; user-select: none; white-space: nowrap; }
.th-sort:hover { color: var(--purple-strong); }
.sort-ar { font-size: 10px; margin-left: 2px; color: var(--purple); }
.sort-ar.dim { opacity: .3; color: var(--muted); }

/* Surbrillance des tickets modifiés à l'actualisation (~30 s) */
@keyframes chgFlash {
  0% { background: #fff3cf; }
  85% { background: #fff8e6; }
  100% { background: transparent; }
}
tr.row-changed td { animation: chgFlash 30s ease-out forwards; }
tr.row-changed td:first-child { box-shadow: inset 3px 0 0 var(--gold-deep); }
.chg-badge { display: inline-block; font-size: 10px; font-weight: 700; color: #fff; background: var(--gold-deep); border-radius: 5px; padding: 1px 6px; margin-left: 6px; vertical-align: middle; }
.sep { height: 1px; background: var(--line); margin: 8px 0 4px; }
table { width: 100%; border-collapse: collapse; font-size: 13.5px; }
th { text-align: left; font-weight: 700; font-size: 11px; letter-spacing: 0.06em; text-transform: uppercase; color: var(--muted); padding: 9px 10px; border-bottom: 2px solid var(--line); }
td { padding: 10px; border-bottom: 1px solid var(--line-soft); vertical-align: top; }
tr:hover td { background: var(--row-alt); }
.k { font-family: "JetBrains Mono", monospace; font-size: 12px; font-weight: 600; color: var(--ink); text-decoration: none; white-space: nowrap; }
.k:hover { color: var(--purple-strong); text-decoration: underline; }
.tag { font-weight: 600; font-size: 11px; color: var(--purple-strong); background: var(--purple-soft); border: 1px solid var(--purple-line); border-radius: 6px; padding: 2px 8px; white-space: nowrap; }
.pill { display: inline-flex; align-items: center; gap: 6px; font-weight: 600; font-size: 11.5px; padding: 4px 10px; border-radius: 99px; white-space: nowrap; }
.pill:before { content: ""; width: 7px; height: 7px; border-radius: 50%; background: currentColor; }
.pill.todo { background: var(--amber-bg); color: var(--amber); }
.pill.prog { background: var(--blue-bg); color: var(--blue); }
.pill.block { background: var(--red-bg); color: var(--red); }
.pill.done { background: var(--green-bg); color: var(--green); }
.late { color: var(--red); font-weight: 600; font-size: 11px; }
.empty { padding: 30px; text-align: center; color: var(--muted); }
.banner { padding: 12px 16px; border-radius: 12px; background: var(--amber-bg); color: var(--amber); font-size: 13px; margin-top: 14px; border: 1px solid #f0dcc0; }

/* Accès invité / lecture seule */
.ro-banner { margin-top: 12px; padding: 10px 16px; border-radius: 12px; background: var(--purple-soft); color: var(--indigo-deep); border: 1px solid #d9d2f3; font-size: 13px; font-weight: 500; display: flex; align-items: center; gap: 8px; }
.owner-bar { margin-top: 12px; display: flex; justify-content: flex-end; }
.invite-btn { font-size: 12.5px; }
.invite-note { background: var(--purple-soft); border: 1px solid #d9d2f3; border-radius: 12px; padding: 12px 14px; font-size: 13px; line-height: 1.5; color: var(--ink); margin: 4px 0 16px; }
.invite-badge { display: inline-block; background: var(--indigo); color: #fff; font-family: "Poppins", sans-serif; font-size: 10.5px; letter-spacing: .05em; text-transform: uppercase; font-weight: 700; padding: 3px 9px; border-radius: 999px; margin-bottom: 8px; }
.foot { margin-top: 30px; text-align: center; color: var(--muted); font-size: 12px; }

@media (max-width: 800px) { .kpis { grid-template-columns: repeat(3, 1fr); } }
@media (max-width: 520px) { .kpis { grid-template-columns: repeat(2, 1fr); } .hdr h1 { font-size: 18px; letter-spacing: 0.05em; } }

/* ===== Onglets ===== */
.tabs { display: flex; gap: 6px; margin: 18px 0 4px; flex-wrap: wrap; }
.tab { font-weight: 600; font-size: 13.5px; cursor: pointer; border: 0; background: transparent; color: var(--muted); padding: 9px 16px; border-radius: 10px; display: inline-flex; align-items: center; gap: 7px; }
.tab:hover { background: var(--purple-soft); color: var(--purple-strong); }
.tab.active { background: var(--indigo); color: #fff; }
.tab .b { background: var(--gold); color: #2a2410; border-radius: 99px; font-size: 11px; padding: 1px 7px; font-weight: 700; }

/* ===== Surlignage « mes tickets » ===== */
tr.mine td { background: #fdf7e8; }
tr.mine td:first-child { box-shadow: inset 3px 0 0 var(--gold); }
.me-badge { display: inline-block; font-size: 10px; font-weight: 700; color: var(--gold-deep); background: var(--gold-soft, #f8f1dd); border: 1px solid #ecd9a8; border-radius: 5px; padding: 1px 6px; margin-left: 6px; vertical-align: middle; }

/* ===== Modale ===== */
.overlay { position: fixed; inset: 0; background: rgba(28, 25, 45, 0.55); backdrop-filter: blur(2px); display: flex; align-items: center; justify-content: center; padding: 24px 16px; z-index: 50; overflow-y: auto; }
.modal { background: var(--card); border-radius: 18px; width: 100%; max-width: 720px; box-shadow: var(--shadow-lg); overflow: hidden; max-height: 92vh; display: flex; flex-direction: column; margin: auto; }
.modal-hd { background: linear-gradient(135deg, var(--orange-deep), var(--orange)); color: #fff; padding: 20px 24px 20px 52px; position: relative; flex-shrink: 0; }
.modal-hd .k { font-family: "JetBrains Mono", monospace; font-weight: 600; color: rgba(255,255,255,.9); font-size: 13px; }
.modal-hd h3 { font-family: "Poppins"; font-weight: 700; font-size: 20px; margin: 4px 0 0; color: #fff; }
.modal-hd .x { position: absolute; top: 16px; right: 18px; cursor: pointer; color: rgba(255,255,255,.85); font-size: 22px; line-height: 1; background: none; border: 0; }
.modal-back { position: absolute; top: 15px; left: 16px; cursor: pointer; color: #fff; font-size: 17px; line-height: 1; background: rgba(255,255,255,.14); border: 1px solid rgba(255,255,255,.22); width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: background .15s ease, transform .15s ease; }
.modal-back:hover { background: rgba(255,255,255,.3); transform: translateX(-2px); }
.modal-back:active { transform: translateX(-2px) scale(.94); }
.modal-bd { padding: 22px 24px; overflow-y: auto; }
.meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 18px; margin-bottom: 16px; }
.meta-grid .cell .l { font-size: 11px; text-transform: uppercase; letter-spacing: .06em; color: var(--muted); font-weight: 600; }
.meta-grid .cell .v { font-size: 14px; color: var(--ink); margin-top: 2px; }
.ta { width: 100%; border: 1px solid var(--line); border-radius: 10px; padding: 11px 13px; font-family: "Inter"; font-size: 13.5px; color: var(--body); resize: vertical; min-height: 90px; }
.ta:focus { outline: 2px solid var(--purple-soft); border-color: var(--purple); }
.row-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 14px; }
.btn-line { font-weight: 600; font-size: 13px; cursor: pointer; border-radius: 10px; padding: 10px 16px; border: 1px solid var(--line); background: #fff; color: var(--body); }
.btn-line:hover { border-color: var(--purple); }
.btn-line:disabled { opacity: .5; cursor: default; }
.btn-solid { font-weight: 600; font-size: 13px; cursor: pointer; border-radius: 10px; padding: 10px 16px; border: 0; background: var(--purple); color: #fff; }
.btn-solid:hover { filter: brightness(1.07); }
.btn-solid.gold { background: var(--orange); color: #fff; }
.btn-solid.gold:hover { background: var(--orange-deep); }
.btn-solid:disabled { opacity: .5; cursor: default; }
.hint { font-size: 12px; color: var(--muted); margin-top: 8px; }
.ok-note { background: var(--green-bg); color: var(--green); border-radius: 9px; padding: 9px 12px; font-size: 13px; margin-top: 10px; }
.warn-note { background: var(--amber-bg); color: var(--amber); border-radius: 9px; padding: 9px 12px; font-size: 13px; margin-top: 10px; }

/* ===== Récap du jour ===== */
.recap-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 16px; }
.recap-card { background: var(--card); border: 1px solid var(--line); border-radius: 16px; box-shadow: var(--shadow); padding: 0; overflow: hidden; }
.recap-hd { background: var(--hd-grad); color: #fff; padding: 12px 16px; display: flex; justify-content: space-between; align-items: center; gap: 10px; box-shadow: inset 0 -2px 0 rgba(199,161,74,.6); }
.recap-hd-name { font-family: "Poppins", sans-serif; font-weight: 700; font-size: 15px; letter-spacing: .02em; }
.recap-hd-meta { font-size: 12px; color: rgba(255,255,255,.85); font-weight: 500; white-space: nowrap; }
.recap-bd { padding: 12px 16px 15px; }
.recap-desc { font-size: 12.5px; line-height: 1.55; color: var(--ink); background: var(--purple-soft); border-left: 3px solid var(--indigo); border-radius: 8px; padding: 9px 12px; margin: 2px 0 12px; }
.recap-desc b { color: var(--indigo-deep); font-weight: 600; }
.recap-desc .rd-label { display: block; font-family: "Poppins", sans-serif; font-size: 10.5px; letter-spacing: .06em; text-transform: uppercase; color: var(--indigo); font-weight: 700; margin-bottom: 3px; }
.recap-card ul { margin: 10px 0; padding-left: 0; list-style: none; }
.recap-card li { font-size: 13px; padding: 5px 0; border-bottom: 1px solid var(--line-soft); display: flex; gap: 8px; align-items: baseline; }
.recap-card li .k { font-family: "JetBrains Mono"; font-size: 11.5px; color: var(--muted); min-width: 72px; }

/* ===== Brief du matin : conteneurs et rythme propres ===== */
.mb-pills { display: flex; flex-wrap: wrap; gap: 6px; margin: 0 0 10px; }
.mb-actions { display: flex; gap: 8px; margin-top: 2px; }
.mb-actions .btn-solid { flex: 1; }
.recap-card ul.mb-list { margin: 4px 0 12px; }
.recap-card li.mb-li { display: block; padding: 8px; border-bottom: 1px solid var(--line-soft); border-radius: 8px; cursor: pointer; transition: background .12s ease; }
.recap-card li.mb-li:hover { background: var(--purple-soft); }
.recap-card li.mb-li:last-of-type { border-bottom: 0; }
.recap-card li.mb-more { display: block; padding: 8px 8px 2px; border-bottom: 0; color: var(--purple-strong); font-weight: 600; font-size: 12.5px; cursor: pointer; }
.recap-card li.mb-more:hover { background: transparent; text-decoration: underline; }

/* ===== Référentiel recette (socle Option→Programmes→Tickets) ===== */
.ref-dom { font-family: "Poppins", sans-serif; font-weight: 700; font-size: 12.5px; letter-spacing: .04em; text-transform: uppercase; color: var(--indigo); margin: 0 0 8px; }
.ref-meta { display: flex; flex-wrap: wrap; gap: 10px; font-size: 11.5px; color: var(--muted); margin-bottom: 6px; }
.ref-meta .late { color: var(--red); font-weight: 700; }
.ref-bar { height: 6px; border-radius: 99px; background: var(--line-soft); overflow: hidden; }
.ref-bar-fill { height: 100%; background: linear-gradient(90deg, var(--purple), #c7a14a); border-radius: 99px; }

/* pipeline bout-en-bout par option */
.ref-pipe { margin-top: 8px; }
.ref-pipe-bar { display: flex; height: 9px; border-radius: 99px; overflow: hidden; background: var(--line-soft); }
.rp-seg { display: block; min-width: 3px; }
.ref-pipe-legend { display: flex; flex-wrap: wrap; gap: 6px 12px; margin-top: 7px; font-size: 11px; color: var(--muted); }
.rp-leg { display: inline-flex; align-items: center; gap: 4px; }
.rp-leg b { color: var(--ink); }
.rp-dot { width: 9px; height: 9px; border-radius: 3px; display: inline-block; }
.st-noncouvert { background: #d6d8e2; }
.st-afaire { background: #b9bed6; }
.st-encours { background: #7c8cf0; }
.st-retour { background: #e2696c; }
.st-recarm { background: #d2a93f; }
.st-reccli { background: #3fae9f; }
.st-mep { background: #5cb87f; }
.ref-bloc { margin-top: 7px; font-size: 11.5px; color: #b23b3b; background: #fcebec; border: 1px solid #f0c7cb; border-radius: 8px; padding: 5px 9px; }
.ref-prog { display: flex; justify-content: space-between; align-items: center; gap: 8px; padding: 7px 6px; border-bottom: 1px solid var(--line-soft); }
.ref-prog:last-of-type { border-bottom: 0; }
.ref-prog-nom { font-family: "JetBrains Mono", monospace; font-size: 12px; color: var(--ink); font-weight: 600; }
.ref-prog-tk { display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap; justify-content: flex-end; }
.ref-prog-none { font-size: 11.5px; color: var(--muted); font-style: italic; }
.ref-tk-link { font-family: "JetBrains Mono", monospace; font-size: 11px; font-weight: 700; color: var(--purple-strong); background: var(--purple-soft); border: 0; border-radius: 6px; padding: 2px 7px; cursor: pointer; }
.ref-tk-link:hover { filter: brightness(.97); text-decoration: underline; }
.pill.rec { background: var(--amber-bg); color: #9a6a00; }
.filters .btn-line.sm { font: inherit; font-size: 12px; font-weight: 600; padding: 5px 11px; border-radius: 8px; border: 1px solid var(--line); background: var(--card); color: var(--ink); cursor: pointer; }
.filters .btn-line.sm.on { background: var(--purple); color: #fff; border-color: var(--purple); }

/* ===== Avatar (photo équipe / initiales) ===== */
.dm-avatar { display: flex; justify-content: center; margin: 2px 0 8px; }
.avatar { box-shadow: 0 1px 6px rgba(20, 16, 60, .18); }
.avatar-ini { user-select: none; }

/* ===== Aperçu document (iframe) ===== */
.doc-frame { width: 100%; height: 60vh; border: 1px solid var(--line); border-radius: 12px; background: #fff; }

/* ===== Formulaire réunion ===== */
.field { margin-bottom: 14px; }
.field label { display: block; font-weight: 600; font-size: 12.5px; color: var(--ink); margin-bottom: 5px; }
.field input[type=text] { width: 100%; border: 1px solid var(--line); border-radius: 10px; padding: 10px 12px; font-size: 14px; }
.drop { border: 1.5px dashed var(--purple-line); border-radius: 12px; padding: 16px; text-align: center; color: var(--muted); font-size: 13px; cursor: pointer; background: var(--purple-soft); }
.chips-files { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
.chip-file { font-size: 12px; background: var(--purple-soft); border: 1px solid var(--purple-line); color: var(--purple-strong); border-radius: 8px; padding: 3px 9px; }

/* ===== Historique ===== */
.hist { background: var(--card); border: 1px solid var(--line); border-radius: 16px; box-shadow: var(--shadow); overflow: hidden; }
.hist-row { display: flex; gap: 14px; align-items: baseline; padding: 12px 18px; border-bottom: 1px solid var(--line-soft); font-size: 13.5px; }
.hist-row .when { font-family: "JetBrains Mono"; font-size: 12px; color: var(--muted); min-width: 130px; }
.hist-row .type { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; color: var(--purple-strong); background: var(--purple-soft); border-radius: 6px; padding: 2px 8px; }

/* ===== Login CPwire ===== */
.login-screen { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 24px;
  background: radial-gradient(120% 120% at 80% 0%, #56517e 0%, var(--cover-1, #4a4670) 38%, var(--cover-2, #322f4d) 100%); }
.login-card { background: var(--card); border-radius: 20px; box-shadow: var(--shadow-lg); padding: 34px 32px; width: 100%; max-width: 400px; }
.login-brand { font-family: "Poppins"; font-weight: 800; font-size: 34px; color: var(--indigo-deep); letter-spacing: -0.5px; }
.login-brand span { color: var(--gold); }
.hdr-brand { display: inline-block; }
.hdr-logo { height: 30px; width: auto; display: block; margin-bottom: 6px; }
.login-logo { background: var(--hd-grad); border-radius: 14px; padding: 20px 22px; text-align: center; margin-bottom: 14px; }
.login-logo img { height: 30px; width: auto; display: inline-block; }
.login-tag { color: var(--muted); font-size: 13px; margin: 2px 0 22px; }
.login-card .field { margin-bottom: 14px; }
.login-card input { width: 100%; border: 1px solid var(--line); border-radius: 10px; padding: 11px 13px; font-size: 14px; }
.login-card input:focus { outline: 2px solid var(--purple-soft); border-color: var(--purple); }
.login-foot { text-align: center; color: var(--muted); font-size: 11.5px; margin-top: 18px; }

/* ===== Édition fiche dossier ===== */
.cover-1 { } /* placeholder */
table.edit-tbl { width: 100%; border-collapse: collapse; font-size: 13px; }
table.edit-tbl th { text-align: left; font-size: 10.5px; text-transform: uppercase; letter-spacing: .05em; color: var(--muted); padding: 4px 6px; }
table.edit-tbl td { padding: 3px 4px; }
table.edit-tbl input, table.edit-tbl select { width: 100%; border: 1px solid var(--line); border-radius: 8px; padding: 7px 8px; font-size: 13px; background: #fff; }
table.edit-tbl input:focus, table.edit-tbl select:focus { outline: 1px solid var(--purple); border-color: var(--purple); }
.x-row { border: 0; background: var(--red-bg); color: var(--red); width: 26px; height: 26px; border-radius: 7px; cursor: pointer; font-size: 16px; line-height: 1; }
.x-row:hover { filter: brightness(0.96); }

/* ===== Lien Jira & explication simple (modale ticket) ===== */
.jira-link { display: inline-block; margin: 0 0 14px; font-weight: 600; font-size: 13px; color: var(--purple-strong);
  background: var(--purple-soft); border: 1px solid var(--purple-line); border-radius: 9px; padding: 8px 14px; text-decoration: none; }
.jira-link:hover { background: #e6e1f8; }
.expl { background: var(--gold-soft, #f8f1dd); border: 1px solid #ecd9a8; border-radius: 12px; padding: 14px 16px; margin: 4px 0 16px; }
.expl-h { font-weight: 700; font-size: 11px; letter-spacing: .07em; text-transform: uppercase; color: var(--gold-deep); margin-bottom: 6px; }
.expl p { white-space: pre-wrap; }
.expl p { margin: 0; color: var(--ink); font-size: 14px; line-height: 1.55; }

/* --- Onglet Développeurs --- */
.dev-list { display: flex; flex-direction: column; gap: 8px; }
.dev-block { border: 1px solid var(--line); border-radius: 12px; overflow: hidden; background: #fff; }
.dev-row { width: 100%; display: flex; align-items: center; gap: 14px; padding: 12px 14px; background: none; border: 0; cursor: pointer; text-align: left; }
.dev-row:hover { background: var(--purple-soft); }
.dev-name { font-weight: 700; min-width: 160px; color: var(--ink); }
.dev-bar { flex: 1; height: 8px; border-radius: 99px; background: var(--line); overflow: hidden; min-width: 60px; }
.dev-bar-fill { display: block; height: 100%; background: linear-gradient(var(--purple), var(--purple-strong)); }
.dev-counts { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; justify-content: flex-end; }
.dev-tot { font-weight: 800; font-size: 15px; color: var(--indigo); min-width: 30px; text-align: right; }
.dev-caret { color: var(--muted); font-size: 18px; margin-left: 4px; font-weight: 700; }

/* Fiche développeur (modale) */
.dev-sec-h { font-family: "Poppins"; font-weight: 700; font-size: 13.5px; color: var(--ink); margin: 18px 0 8px; }
.dev-stats { display: flex; gap: 8px; flex-wrap: wrap; }
.dstat { flex: 1; min-width: 84px; border: 1px solid var(--line); border-radius: 12px; padding: 10px 12px; background: #fff; }
.dstat .v { font-family: "Poppins"; font-weight: 800; font-size: 23px; color: var(--ink); line-height: 1; }
.dstat .l { font-size: 10.5px; text-transform: uppercase; letter-spacing: .04em; color: var(--muted); margin-top: 5px; font-weight: 700; }
.dstat.done { background: #eef7f0; border-color: #cfe8d6; }
.dstat.prog { background: #eef1fb; border-color: #d3dcf5; }
.dstat.todo { background: #fdf6e6; border-color: #ecd9a8; }
.dstat.block { background: #fcebec; border-color: #f0c7cb; }
.dstat.flagged { background: var(--orange-soft); border-color: #f3d6bd; }

/* ===== Fiche développeur — entête « carte » (dégradé or + pointillés) ===== */
.dev-hero { text-align: center; padding: 22px 24px 18px; background: linear-gradient(120deg, #b9842a 0%, #d9ad44 58%, #6e5cc4 175%); overflow: hidden; }
.dev-hero::before { content: ""; position: absolute; inset: 0; background-image: radial-gradient(rgba(255,255,255,.22) 1.1px, transparent 1.3px); background-size: 15px 15px; opacity: .5; pointer-events: none; }
.dev-hero > * { position: relative; }
.dev-hero-k { font-family: "JetBrains Mono", monospace; font-weight: 600; font-size: 11.5px; letter-spacing: .06em; text-transform: uppercase; color: rgba(255,255,255,.85); }
.dev-hero-av { display: flex; justify-content: center; margin: 8px 0 6px; }
.dev-hero-av .avatar { box-shadow: 0 0 0 4px rgba(255,255,255,.85), 0 6px 18px rgba(40,28,10,.35); }
.dev-hero-name { font-family: "Poppins"; font-weight: 800; font-size: 23px; margin: 2px 0 9px; color: #fff; }
.dev-hero-meta { display: flex; justify-content: center; flex-wrap: wrap; gap: 8px; }
.dhm { font-size: 12.5px; font-weight: 600; color: #fff; background: rgba(255,255,255,.16); border: 1px solid rgba(255,255,255,.28); border-radius: 999px; padding: 3px 11px; }
.dhm.gold { background: rgba(255,255,255,.92); color: #8a6516; border-color: transparent; }
.dev-hero-email { display: inline-block; margin-top: 9px; font-size: 12.5px; font-weight: 600; color: #fff; text-decoration: none; opacity: .92; }
.dev-hero-email:hover { text-decoration: underline; }
.dev-hero-email.muted { color: rgba(255,255,255,.72); font-weight: 500; font-style: italic; }

/* compteurs cliquables (filtrent la liste en dessous) */
.dev-stats .dstat { cursor: pointer; text-align: left; font: inherit; transition: transform .1s ease, box-shadow .12s ease, border-color .12s ease; }
.dev-stats .dstat:hover { transform: translateY(-1px); box-shadow: 0 3px 10px rgba(20,16,60,.10); }
.dev-stats .dstat.on { border-color: var(--purple); box-shadow: inset 0 0 0 2px var(--purple-soft), 0 3px 10px rgba(20,16,60,.12); }
.month-chart { display: flex; align-items: flex-end; gap: 10px; height: 130px; padding: 6px 4px 0; border: 1px solid var(--line); border-radius: 12px; }
.mc-col { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: flex-end; height: 100%; gap: 4px; }
.mc-val { font-weight: 800; font-size: 12px; color: var(--indigo); }
.mc-bar-wrap { width: 100%; max-width: 42px; flex: 1; display: flex; align-items: flex-end; }
.mc-bar { width: 100%; min-height: 3px; border-radius: 6px 6px 0 0; background: linear-gradient(var(--purple), var(--purple-strong)); transition: height .2s ease; }
.mc-lbl { font-size: 11px; color: var(--muted); text-transform: capitalize; font-weight: 600; }
.period-sum { background: var(--purple-soft); border: 1px solid var(--purple-line); border-radius: 10px; padding: 9px 13px; font-size: 13.5px; color: var(--ink); margin: 4px 0 12px; }
.proj-tbl { width: 100%; border-collapse: collapse; margin: 4px 0 6px; }
.proj-tbl th { text-align: left; font-size: 10.5px; text-transform: uppercase; letter-spacing: .05em; color: var(--muted); padding: 7px 10px; border-bottom: 2px solid var(--line); }
.proj-tbl td { padding: 8px 10px; border-bottom: 1px solid var(--line-soft); }
.dev-when { font-size: 11.5px; color: var(--muted); white-space: nowrap; }

/* Drapeau (flagged) */
.flag { color: var(--orange-deep); font-weight: 700; }
.flag-badge { display: inline-block; font-size: 10px; font-weight: 700; color: #fff; background: var(--orange-deep); border-radius: 5px; padding: 1px 6px; margin-left: 6px; vertical-align: middle; }

/* Tableaux alignés dans les fiches (colonnes fixes -> tout aligné) */
.fiche-tbl, .act-tbl { width: 100%; border-collapse: collapse; table-layout: fixed; margin: 6px 0 10px; font-size: 13px; }
.fiche-tbl th, .act-tbl th { text-align: left; font-size: 10.5px; text-transform: uppercase; letter-spacing: .04em; color: var(--muted); padding: 8px 10px; border-bottom: 2px solid var(--line); }
.fiche-tbl td, .act-tbl td { padding: 10px; border-bottom: 1px solid var(--line-soft); vertical-align: top; line-height: 1.45; }
.fiche-tbl tbody tr { cursor: pointer; }
.fiche-tbl tbody tr:hover td { background: var(--purple-soft); }
.fiche-tbl tbody tr:nth-child(even) td, .act-tbl tbody tr:nth-child(even) td { background: var(--zebra, rgba(110,92,196,.035)); }
.fiche-tbl tbody tr:nth-child(even):hover td { background: var(--purple-soft); }
/* Les colonnes à contenu variable PEUVENT passer à la ligne (sinon débordement = chevauchement). */
.fiche-tbl .c-cle { width: 92px; white-space: nowrap; }
.fiche-tbl .c-proj { width: 116px; white-space: normal; word-break: break-word; }
.fiche-tbl .c-date { width: 84px; white-space: nowrap; color: var(--muted); font-size: 12px; }
.fiche-tbl .c-stat { width: 134px; white-space: normal; }
.fiche-tbl .c-res { white-space: normal; word-break: break-word; }
.act-tbl .c-when { width: 116px; white-space: normal; color: var(--muted); font-size: 12px; }
.act-tbl .c-who { width: 128px; font-weight: 600; white-space: normal; word-break: break-word; }
.act-tbl .c-act { white-space: normal; word-break: break-word; }
/* Dans ces tableaux denses, les pastilles de statut peuvent se mettre sur 2 lignes. */
.fiche-tbl .pill, .act-tbl .pill { white-space: normal; line-height: 1.25; }
.worklog-total { background: var(--orange-soft); border: 1px solid #f3d6bd; border-radius: 10px; padding: 9px 13px; font-size: 14px; color: var(--ink); margin: 4px 0 10px; }

/* Barre d'export / partage (présente dans chaque modale) */
.export-bar { display: flex; align-items: center; gap: 7px; flex-wrap: wrap; background: var(--purple-soft); border: 1px solid var(--purple-line); border-radius: 10px; padding: 8px 12px; margin: 2px 0 14px; }
.eb-lbl { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; color: var(--purple); margin-right: 2px; }
.act-empty { color: var(--muted); font-size: 13px; padding: 6px 0; }

/* Récap par client (historique) */
.cli-block { border: 1px solid var(--line); border-radius: 12px; overflow: hidden; margin: 14px 0; box-shadow: var(--shadow); }
.cli-h { display: flex; align-items: center; gap: 10px; margin: 0; flex-wrap: wrap; background: var(--hd-grad); color: #fff; padding: 10px 14px; box-shadow: inset 0 -2px 0 rgba(199,161,74,.6); }
.cli-h .tag { background: rgba(255,255,255,.2); color: #fff; }
.cli-meta { font-size: 12px; color: rgba(255,255,255,.85); }
.cli-block .fiche-tbl { margin: 0; }

/* Lignes du récap du jour : 2 niveaux (clé+statut, puis résumé, puis dev) */
.recap-card li.ri { display: block; padding: 9px 6px; border-bottom: 1px solid var(--line-soft); cursor: pointer; border-radius: 8px; }
.recap-card li.ri:hover { background: var(--purple-soft); }
.recap-card li.ri:last-of-type { border-bottom: 0; }
.ri-top { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.ri-top .k { min-width: 0; }
.ri-res { font-size: 13px; color: var(--body); margin: 4px 0 6px; line-height: 1.4; word-break: break-word; }
.ri-dev { line-height: 1; }
.recap-card li.ri-more { display: block; padding: 8px 6px 2px; font-size: 12.5px; border: 0; }

/* ---- Conteneur de filtres structuré (bandeau couleur header) ---- */
.filter-box { border: 1px solid var(--line); border-radius: 14px; overflow: hidden; margin-bottom: 6px; box-shadow: var(--shadow); }
.filter-box-hd { background: var(--hd-grad); color: #fff; font-weight: 700; font-size: 12px; letter-spacing: .11em; text-transform: uppercase; padding: 10px 15px; display: flex; align-items: center; justify-content: space-between; box-shadow: inset 0 -2px 0 rgba(199,161,74,.6); }
.filter-box-hd > span:first-child { display: inline-flex; align-items: center; gap: 9px; }
.filter-box-hd > span:first-child::before { content: ""; width: 4px; height: 15px; border-radius: 2px; background: var(--gold); display: inline-block; }
.filter-reset { border: 1px solid rgba(255,255,255,.3); background: rgba(255,255,255,.12); color: #fff; border-radius: 8px; font-size: 11.5px; font-weight: 600; padding: 4px 10px; cursor: pointer; letter-spacing: 0; text-transform: none; }
.filter-reset:hover { background: rgba(255,255,255,.24); }
.filter-box-bd { padding: 12px 14px 8px; background: var(--card); }
.filter-grp { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; padding: 7px 0; border-bottom: 1px solid var(--line-soft); }
.filter-grp:last-child { border-bottom: 0; }
.filter-grp .fg-lbl { min-width: 84px; flex-shrink: 0; }
.fg-chips { display: flex; gap: 7px; flex-wrap: wrap; }

/* Onglets clients (historique des récaps) */
.ctabs { display: flex; gap: 6px; flex-wrap: wrap; margin: 0 0 12px; }
.ctab { border: 1px solid var(--line); background: var(--card); color: var(--muted); font-weight: 600; font-size: 13px; padding: 8px 15px; border-radius: 10px; cursor: pointer; transition: all .12s ease; }
.ctab:hover { border-color: var(--purple-line); color: var(--ink); }
.ctab.active { background: var(--hd-grad); color: #fff; border-color: var(--indigo); }
.dev-items { list-style: none; margin: 0; padding: 4px 8px 10px; border-top: 1px solid var(--line); }
.dev-items li { display: flex; align-items: center; gap: 10px; padding: 7px 8px; border-radius: 8px; font-size: 13px; }
.dev-items li:hover { background: var(--purple-soft); }
@media (max-width: 640px) {
  .dev-name { min-width: 110px; font-size: 13px; }
  .dev-bar { display: none; }
}

/* --- Toast (message subtil après actualisation) --- */
.toast {
  position: fixed; left: 50%; bottom: 26px; transform: translateX(-50%);
  background: var(--indigo); color: #fff; font-size: 13px; font-weight: 600;
  padding: 11px 18px; border-radius: 99px; box-shadow: 0 10px 30px rgba(44,41,69,.28);
  z-index: 90; animation: toast-in .25s ease-out; max-width: 90vw; text-align: center;
}
@keyframes toast-in { from { opacity: 0; transform: translate(-50%, 10px); } to { opacity: 1; transform: translate(-50%, 0); } }

/* ===================== PWA — bouton d'installation ===================== */
.install-fab {
  position: fixed; right: 16px; z-index: 95;
  bottom: calc(16px + env(safe-area-inset-bottom, 0px));
  background: var(--gold); color: #2a2410; border: 0; border-radius: 99px;
  font-weight: 700; font-size: 13px; padding: 12px 17px; cursor: pointer;
  box-shadow: 0 10px 30px rgba(44,41,69,.32);
}
.install-fab:hover { filter: brightness(1.06); }
.install-ios { position: fixed; inset: 0; background: rgba(28,25,45,.55); backdrop-filter: blur(2px);
  display: flex; align-items: flex-end; justify-content: center; z-index: 96; padding: 14px; }
.install-ios-box { background: #fff; border-radius: 16px; padding: 20px 22px; width: 100%; max-width: 420px; box-shadow: var(--shadow-lg); }
.install-ios-box ol { margin: 12px 0 16px; padding-left: 20px; } .install-ios-box li { margin: 8px 0; }

/* ===================== Optimisation mobile ===================== */
@media (max-width: 768px) {
  html, body { max-width: 100%; overflow-x: hidden; }
  .wrap { padding: max(14px, env(safe-area-inset-top)) max(13px, env(safe-area-inset-right)) calc(80px + env(safe-area-inset-bottom)) max(13px, env(safe-area-inset-left)); max-width: 100%; box-sizing: border-box; }
  .hdr { padding: 20px 18px; border-radius: 18px; }
  .hdr h1 { font-size: 20px; letter-spacing: 0.06em; }
  .hdr .sub { font-size: 13px; }
  .hdr-row { gap: 14px; }
  .hdr-actions { align-items: stretch; width: 100%; }
  .hdr-actions > div { width: 100%; }
  .hdr-actions .btn { flex: 1; text-align: center; }
  .hdr-bar { justify-content: stretch; }
  .hdr-search { width: 100%; flex: 1 1 100%; }
  .hdr-bar .btn { height: 42px; }
  .src { text-align: left; }

  /* Onglets : barre défilante horizontale (look appli) */
  .tabs { flex-wrap: nowrap; overflow-x: auto; -webkit-overflow-scrolling: touch; scrollbar-width: none; padding-bottom: 2px; }
  .tabs::-webkit-scrollbar { display: none; }
  .tab { white-space: nowrap; flex: 0 0 auto; }

  .section-title { font-size: 17px; margin: 22px 0 12px; }
  .recap-grid { grid-template-columns: 1fr; }

  /* Boutons confortables au doigt */
  .btn, .btn-solid, .btn-line { min-height: 44px; }

  /* Tableau des tickets : transformé en cartes (voir bloc « MOBILE — cartes & accordéons » en bas) */

  /* Modales plus larges */
  .overlay { padding: 14px 10px; }
  .modal { max-width: 100%; }

  /* Évite tout débordement horizontal */
  td, .pcard, .recap-card { word-break: break-word; }
}

@media (max-width: 480px) {
  .kpis { gap: 8px; }
  .install-fab { font-size: 12.5px; padding: 11px 14px; }
}

/* ===== Onglet « En cours » : jauges par client + qui fait quoi ===== */
.enc-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(430px, 1fr)); gap: 14px; }
@media (max-width: 920px) { .enc-grid { grid-template-columns: 1fr; } }
.enc-card { border: 1px solid var(--line); border-radius: 14px; overflow: hidden; box-shadow: var(--shadow); background: var(--card); }
.enc-hd { background: var(--hd-grad); color: #fff; padding: 11px 15px; display: flex; align-items: center; justify-content: space-between; box-shadow: inset 0 -2px 0 rgba(199,161,74,.6); }
.enc-name { font-weight: 700; font-size: 14.5px; letter-spacing: .02em; }
.enc-pct { font-family: "Poppins", sans-serif; font-weight: 800; font-size: 17px; }
.enc-bd { padding: 13px 15px 15px; }
.enc-gauge { height: 10px; border-radius: 99px; background: var(--purple-soft); overflow: hidden; margin-bottom: 11px; }
.enc-gauge > span { display: block; height: 100%; border-radius: 99px; background: linear-gradient(90deg, var(--indigo), var(--purple)); transition: width .4s ease; }
.enc-chips { display: flex; gap: 6px; flex-wrap: wrap; }
.enc-sub { font-size: 11px; text-transform: uppercase; letter-spacing: .06em; color: var(--muted); font-weight: 700; margin-top: 12px; padding-top: 11px; border-top: 1px solid var(--line-soft); }
.enc-devs { display: flex; flex-direction: column; gap: 10px; margin-top: 8px; }
.enc-dev-h { display: flex; align-items: center; gap: 8px; margin-bottom: 3px; }
.enc-dev-n { font-size: 11px; font-weight: 700; color: var(--purple); background: var(--purple-soft); border-radius: 99px; padding: 1px 8px; }
.enc-tix { list-style: none; margin: 0; padding: 0; }
.enc-tix li { display: flex; align-items: center; gap: 8px; padding: 6px; border-radius: 8px; cursor: pointer; font-size: 13px; }
.enc-tix li:hover { background: var(--purple-soft); }
.enc-tix li .k { flex-shrink: 0; }
.enc-tix-res { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.enc-tix .pill { flex-shrink: 0; }

/* ===== Bouton Relancer (header) ===== */
.btn.relaunch { font-size: 17px; line-height: 1; padding: 0 12px; }

/* ===== Barre d'export : message d'erreur ===== */
.eb-err { font-size: 12px; color: var(--red); margin-left: 4px; }

/* ===== Écran de reprise (Error Boundary) ===== */
.crash { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 24px; background: var(--bg, #f4f3fa); }
.crash-card { background: #fff; border: 1px solid var(--line); border-radius: 18px; box-shadow: var(--shadow-lg); padding: 32px; max-width: 460px; text-align: center; }
.crash-logo { height: 30px; width: auto; margin-bottom: 14px; }
.crash-card h2 { font-family: "Poppins", sans-serif; font-size: 20px; color: var(--ink); margin: 0 0 8px; }
.crash-card p { color: var(--muted); font-size: 14px; margin: 8px 0; }
.crash-actions { display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; margin: 16px 0 6px; }
.crash-hint { font-size: 12px; }

/* ===== Panneau de notifications (cloche) ===== */
.bell-wrap { position: relative; }
.notif-backdrop { position: fixed; inset: 0; z-index: 1999; background: rgba(20,18,40,.04); }
.notif-panel { position: fixed; top: 72px; right: max(16px, calc(50vw - 566px)); width: 360px; max-width: 92vw; background: #fff; color: var(--ink); border: 1px solid var(--line); border-radius: 14px; box-shadow: var(--shadow-lg); z-index: 2000; overflow: hidden; }
.notif-hd { display: flex; align-items: center; justify-content: space-between; padding: 11px 14px; background: var(--hd-grad); color: #fff; box-shadow: inset 0 -2px 0 rgba(199,161,74,.6); }
.notif-title { font-weight: 700; font-size: 12.5px; letter-spacing: .07em; text-transform: uppercase; }
.notif-toggle { display: inline-flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600; cursor: pointer; }
.notif-toggle input { cursor: pointer; accent-color: var(--gold); }
.notif-sub { display: flex; align-items: center; justify-content: space-between; padding: 8px 14px; font-size: 12px; color: var(--muted); border-bottom: 1px solid var(--line-soft); }
.notif-clear { border: 0; background: none; color: var(--purple); font-weight: 600; font-size: 12px; cursor: pointer; }
.notif-clear:hover { text-decoration: underline; }
.notif-list { max-height: 380px; overflow-y: auto; }
.notif-empty { padding: 24px 16px; text-align: center; color: var(--muted); font-size: 13px; line-height: 1.5; }
.notif-item { display: flex; gap: 10px; width: 100%; text-align: left; background: none; border: 0; border-bottom: 1px solid var(--line-soft); padding: 11px 14px; cursor: pointer; align-items: flex-start; }
.notif-item:last-child { border-bottom: 0; }
.notif-item:hover { background: var(--purple-soft); }
.notif-item.unread { background: rgba(110,92,196,.06); }
.ni-dot { width: 8px; height: 8px; border-radius: 50%; margin-top: 5px; flex-shrink: 0; background: transparent; }
.notif-item.unread .ni-dot { background: var(--indigo); }
.ni-body { display: flex; flex-direction: column; gap: 5px; min-width: 0; flex: 1; }
.ni-line { font-size: 13px; color: var(--ink); line-height: 1.35; word-break: break-word; }
.ni-meta { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.ni-time { font-size: 11.5px; color: var(--muted); }
@media (max-width: 560px) { .notif-panel { position: fixed; top: 64px; right: 8px; left: 8px; width: auto; } }

/* ===== Bouton « Tout recharger » (icône soignée) ===== */
.reload-btn { display: inline-flex; align-items: center; gap: 8px; border: 1px solid var(--purple-line); background: #fff; color: var(--purple-strong); border-radius: 99px; padding: 6px 14px 6px 7px; font-size: 12.5px; font-weight: 700; cursor: pointer; box-shadow: var(--shadow); transition: transform .12s ease, box-shadow .12s ease, background .12s ease; }
.reload-btn:hover { background: var(--purple-soft); transform: translateY(-1px); box-shadow: var(--shadow-lg); }
.reload-btn:disabled { opacity: .7; cursor: default; transform: none; }
.reload-ico { display: inline-flex; align-items: center; justify-content: center; width: 24px; height: 24px; border-radius: 50%; background: linear-gradient(135deg, var(--purple), var(--purple-strong)); color: #fff; font-size: 15px; line-height: 1; box-shadow: inset 0 0 0 2px rgba(199,161,74,.45); }
.reload-txt { letter-spacing: .01em; }
@keyframes spin360 { to { transform: rotate(360deg); } }
.reload-btn.spin .reload-ico { animation: spin360 .9s linear infinite; }

/* ===== Réunions — cartes & aperçu ===== */
.meet-card { border: 1px solid var(--line); border-radius: 16px; overflow: hidden; box-shadow: var(--shadow); background: var(--card); }
.meet-hd { background: var(--hd-grad); color: #fff; padding: 13px 18px; font-weight: 700; font-size: 14.5px; letter-spacing: .03em; box-shadow: inset 0 -2px 0 rgba(199,161,74,.6); }
.meet-bd { padding: 18px 18px 20px; }
.meet-grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
@media (max-width: 640px) { .meet-grid2 { grid-template-columns: 1fr; gap: 0; } }
.fselect.block { display: block; width: 100%; border-radius: 12px; padding: 11px 13px; font-size: 14px; font-weight: 500; }
.prep-result { margin-top: 18px; border-top: 2px solid var(--line-soft); padding-top: 16px; animation: prep-in .25s ease-out; }
@keyframes prep-in { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
.prep-result-hd { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 10px; flex-wrap: wrap; }
.prep-result-t { font-family: "Poppins", sans-serif; font-weight: 700; font-size: 14px; color: var(--ink); }
.prep-result .doc-frame { height: 64vh; }

/* ===== Renforts mobile (lisibilité, pas de coupe de mots) ===== */
@media (max-width: 768px) {
  .meet-bd { padding: 14px 14px 16px; }
  .prep-result .doc-frame { height: 56vh; }
  .ta { min-height: 92px; }
  /* Coupe propre des longues chaînes, jamais en plein milieu d'un mot court */
  .ni-line, .enc-name, .dev-name, .pcard, .recap-card, td, .meet-bd, .field label { overflow-wrap: break-word; word-break: normal; }
  /* Champs et selects bien au doigt */
  input[type="text"], textarea, select, .fselect { font-size: 16px; } /* >=16px évite le zoom auto iOS */
}

/* ===== Intervenants (tableau) + e-mail (fiche dev) ===== */
.who-sep { color: var(--muted); }
.who-none { color: var(--muted); font-style: italic; }
.dm-email { display: inline-block; margin-top: 4px; font-size: 13px; font-weight: 600; color: #fff; text-decoration: none; opacity: .92; }
.dm-email:hover { text-decoration: underline; }
.dm-email.muted { color: rgba(255,255,255,.7); font-weight: 500; font-style: italic; }

/* ===== Fiche dev : "sur quoi il travaille" + activité réelle ===== */
.work-tbl .c-h, .work-tbl .c-since, .work-tbl .c-act { white-space: nowrap; }
.work-tbl .c-h { width: 96px; }
.work-tbl .c-since { width: 104px; color: var(--body); }
.work-tbl .c-act { width: 168px; }
.wk { display: inline-flex; align-items: center; gap: 5px; font-size: 11.5px; font-weight: 700; padding: 3px 9px; border-radius: 99px; white-space: nowrap; }
.wk-on { background: #e7f6ec; color: #1f8f4d; }
.wk-warn { background: #fbf0dc; color: #9a6a12; }
.wk-off { background: #f1eff7; color: var(--muted); font-weight: 600; }
.wk-load { background: #f1eff7; color: var(--muted); }

/* ===== Développeurs : masquer / réafficher ===== */
.dev-row { width: 100%; text-align: left; cursor: pointer; }
.dev-row.hid { opacity: .55; }
.dev-hide { border: 1px solid var(--line); background: #fff; color: var(--muted); font-size: 11px; font-weight: 700; border-radius: 99px; padding: 3px 10px; cursor: pointer; }
.dev-hide:hover { background: var(--purple-soft); color: var(--purple-strong); border-color: var(--purple-line); }
.dev-hidden-bar { display: flex; justify-content: center; padding: 12px 0 2px; }
.dev-del-tag { margin-left: 8px; font-size: 10.5px; font-weight: 700; text-transform: uppercase; letter-spacing: .04em; color: #b23; background: #fdeef0; padding: 2px 7px; border-radius: 99px; }

/* ===== Notif : ligne d'explication (qui a fait quoi) ===== */
.ni-expl { font-size: 12px; color: var(--purple-strong); line-height: 1.3; word-break: break-word; }
.ni-expl b { color: var(--ink); }

/* ===== Ticket : bannière "Dernière mise à jour" ===== */
.last-update { background: linear-gradient(135deg, var(--purple-soft), #fff); border: 1px solid var(--purple-line); border-left: 4px solid var(--purple); border-radius: 12px; padding: 11px 14px; margin-top: 14px; margin-bottom: 14px; }
.lu-tag { display: inline-block; font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: .07em; color: var(--purple-strong); margin-bottom: 5px; }
.lu-body { font-size: 14px; color: var(--ink); line-height: 1.5; }
.lu-who { font-weight: 700; }
.lu-sep { color: var(--purple); font-weight: 700; }
.lu-when { display: block; margin-top: 6px; font-size: 11.5px; color: var(--muted); }

/* Transition de statut dans l'historique : ancien (barré) → nouveau (mis en avant) */
.chg-field { display: inline-block; font-size: 10.5px; text-transform: uppercase; letter-spacing: .03em; color: var(--muted); font-weight: 700; margin-right: 7px; }
.chg-from { color: var(--muted); text-decoration: line-through; text-decoration-color: rgba(0,0,0,.28); }
.chg-arrow { color: var(--purple); margin: 0 7px; font-weight: 700; }
.chg-to { font-weight: 700; color: var(--purple-strong); background: var(--purple-soft); border: 1px solid var(--purple-line); border-radius: 6px; padding: 1px 8px; white-space: normal; }

/* Panneau Développeurs : bandeau dégradé en tête (comme les autres) */
.dev-panel { padding: 0; overflow: hidden; }
.dev-panel .recap-hd { margin: 0; }
.dev-panel-bd { padding: 16px 18px 14px; }

/* Panneau Cockpit : même bandeau dégradé que les autres conteneurs */
.cockpit-panel { padding: 0; overflow: hidden; }
.cockpit-panel .recap-hd { margin: 0; }
.cockpit-bd { padding: 14px 18px; }

/* Boutons de génération de CR (détaillé + écrit) empilés */
.cr-btns { display: flex; flex-direction: column; gap: 8px; }
.cr-btns .btn-solid { width: 100%; }

/* Historique (onglet) : sur écran étroit, on masque la colonne Dév. pour éviter
   tout chevauchement entre Dév. / Statut / Date (l'info dev reste dans la fiche ticket). */
@media (max-width: 680px) {
  .cli-block .fiche-tbl .c-proj { display: none; }
}

/* ===== Recherche : suggestions en accordéon ===== */
.search-suggest { background: #fff; border: 1px solid var(--line); border-radius: 12px; box-shadow: var(--shadow-lg); overflow: hidden; max-height: 60vh; overflow-y: auto; }
.ss-empty { padding: 14px 16px; color: var(--muted); font-size: 13px; }
.ss-item { display: grid; grid-template-columns: auto 1fr auto; align-items: center; gap: 10px; width: 100%; text-align: left; background: none; border: 0; border-bottom: 1px solid var(--line-soft); padding: 10px 14px; cursor: pointer; }
.ss-item:last-child { border-bottom: 0; }
.ss-item:hover { background: var(--purple-soft); }
.ss-key { font-family: "JetBrains Mono", monospace; font-weight: 700; font-size: 12px; color: var(--purple-strong); background: var(--purple-soft); padding: 2px 7px; border-radius: 6px; white-space: nowrap; }
.ss-res { font-size: 13px; color: var(--ink); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ss-meta { display: inline-flex; align-items: center; gap: 8px; font-size: 11.5px; color: var(--muted); white-space: nowrap; }
.ss-all { width: 100%; text-align: center; background: var(--purple-soft); border: 0; border-top: 1px solid var(--line); padding: 11px 14px; cursor: pointer; font-weight: 700; font-size: 13px; color: var(--purple-strong); }
.ss-all:hover { background: #e9defb; }
.ss-modal-back { position: fixed; inset: 0; background: rgba(24,18,48,.5); backdrop-filter: blur(2px); z-index: 3000; display: flex; align-items: flex-start; justify-content: center; padding: 6vh 16px 16px; }
.ss-modal { background: #fff; border-radius: 16px; box-shadow: var(--shadow-lg); width: min(760px, 100%); max-height: 84vh; display: flex; flex-direction: column; overflow: hidden; }
.ss-modal-hd { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 14px 18px; border-bottom: 1px solid var(--line); font-weight: 600; color: var(--ink); }
.ss-modal-hd b { color: var(--purple-strong); background: var(--purple-soft); padding: 1px 9px; border-radius: 999px; margin-left: 6px; font-size: 13px; }
.ss-modal-hd button { border: 0; background: var(--purple-soft); color: var(--ink); width: 30px; height: 30px; border-radius: 9px; font-size: 18px; cursor: pointer; line-height: 1; }
.ss-modal-hd button:hover { background: #e9defb; }
.ss-modal-list { overflow-y: auto; }
.ss-modal-list .ss-item:hover { background: var(--purple-soft); }

/* ===== Réunion : composer éditable ===== */
.prep-edit { margin-top: 16px; border-top: 2px solid var(--line-soft); padding-top: 14px; }
.prep-edit-h { font-family: "Poppins", sans-serif; font-weight: 700; font-size: 14px; color: var(--ink); margin-bottom: 10px; }
.part-row { display: grid; grid-template-columns: 1fr 1fr auto; gap: 8px; margin-bottom: 8px; align-items: center; }
@media (max-width: 640px) { .part-row { grid-template-columns: 1fr auto; } }
.part-row .fselect { width: 100%; border-radius: 10px; padding: 9px 12px; font-size: 13.5px; font-weight: 500; }
.part-row input { width: 100%; }
.part-del { border: 1px solid var(--line); background: #fff; color: var(--muted); width: 36px; height: 36px; border-radius: 8px; cursor: pointer; font-size: 18px; line-height: 1; }
.part-del:hover { background: #fdeef0; color: #c0392b; border-color: #f0c7cb; }
.chk-list { display: flex; flex-direction: column; gap: 8px; border: 1px solid var(--line); border-radius: 10px; padding: 11px 13px; max-height: 240px; overflow-y: auto; }
.chk { display: flex; align-items: flex-start; gap: 9px; font-size: 13px; color: var(--ink); cursor: pointer; line-height: 1.4; }
.chk input { margin-top: 3px; accent-color: var(--purple); flex-shrink: 0; }

/* ===== En cours : vue par développeur ===== */
.enc-name.clk { cursor: pointer; text-decoration: underline; text-decoration-thickness: 1px; text-underline-offset: 2px; text-decoration-color: rgba(255,255,255,.45); }
.enc-name.clk:hover { text-decoration-color: var(--gold); }
.enc-name.del { opacity: .6; text-decoration: line-through; }
.enc-tix .tag { flex-shrink: 0; }

/* ===== Ticket : sous-titres de l'historique ===== */
.act-sub { font-size: 11px; text-transform: uppercase; letter-spacing: .06em; color: var(--muted); font-weight: 700; margin: 16px 0 6px; }
.act-sub:first-of-type { margin-top: 10px; }

/* ===== CRA — Compte rendu d'activité ===== */
.cra-form { display: flex; flex-wrap: wrap; gap: 12px; align-items: end; }
.cra-form label { font-size: 12.5px; color: var(--muted); font-weight: 600; display: flex; align-items: center; gap: 6px; }
.cra-form input[type="date"], .cra-form select { font-family: inherit; font-size: 13px; padding: 7px 9px; border: 1px solid var(--line); border-radius: 9px; background: #fff; color: var(--ink); }
.cra-kpi-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.cra-kpi { background: var(--card); border: 1px solid var(--line); border-radius: 13px; box-shadow: var(--shadow); padding: 13px 15px; }
.cra-kpi-n { display: block; font-family: "Poppins", sans-serif; font-weight: 800; font-size: 24px; line-height: 1.05; color: var(--indigo-deep); }
.cra-kpi-l { display: block; font-size: 11px; text-transform: uppercase; letter-spacing: .05em; color: var(--muted); font-weight: 700; margin-top: 4px; }
.cra-card { background: var(--card); border: 1px solid var(--line); border-radius: 16px; box-shadow: var(--shadow); overflow: hidden; margin-top: 16px; }
.cra-card-h { background: var(--hd-grad); color: #fff; padding: 12px 16px; font-weight: 700; font-size: 15px; letter-spacing: .02em; box-shadow: inset 0 -2px 0 rgba(199,161,74,.6); display: flex; align-items: center; gap: 10px; }
.cra-card-meta { font-size: 12px; font-weight: 500; color: rgba(255,255,255,.82); }
.cra-tbl { margin: 0; }
.cra-tbl th.num, .cra-tbl td.num { text-align: right; white-space: nowrap; }
.cra-tbl tr.cra-total td { border-top: 2px solid var(--line); background: var(--purple-soft); }
.cra-tbl tr.clk { cursor: pointer; }
.cra-tbl tr.clk:hover { background: var(--purple-soft); }
.cra-bar { display: inline-block; width: 64px; height: 7px; border-radius: 99px; background: var(--purple-soft); overflow: hidden; vertical-align: middle; margin-right: 7px; }
.cra-bar > span { display: block; height: 100%; border-radius: 99px; background: linear-gradient(90deg, var(--indigo), var(--purple)); }
.cra-proj { display: flex; flex-wrap: wrap; gap: 5px; }
.cra-proj .tag { font-size: 11px; }
@media (max-width: 720px) { .cra-kpi-row { grid-template-columns: 1fr 1fr; } }

/* Badge de version (pour vérifier d'un coup d'œil que le bon code est en ligne) */
.hdr-build { display: inline-block; margin-left: 8px; padding: 1px 8px; border-radius: 99px; background: var(--gold); color: #2c2429; font-weight: 800; font-size: 10px; letter-spacing: .04em; vertical-align: middle; }

/* ===================== MOBILE — propre, sans wrap, logique de cartes/accordéons ===================== */
@media (max-width: 768px) {
  /* Barre de statut iOS (Dynamic Island) en fond sombre : heure/batterie restent lisibles
     et le contenu ne passe plus dessous (combiné aux marges safe-area de .wrap). */
  /* Zone de la Dynamic Island : en couleur de fond (plus de bandeau bleu). */
  body::before {
    content: ""; position: fixed; top: 0; left: 0; right: 0;
    height: env(safe-area-inset-top, 0px);
    background: var(--bg); z-index: 100; pointer-events: none;
  }
  /* Aucun débordement latéral possible. */
  img, svg, pre, table { max-width: 100%; }
  .notif-panel { top: calc(64px + env(safe-area-inset-top, 0px)); }

  /* ---- Tableau cockpit → UNE CARTE PAR TICKET (aucune info masquée, aucun wrap) ---- */
  .cockpit-bd > table,
  .cockpit-bd > table > tbody,
  .cockpit-bd > table > tbody > tr,
  .cockpit-bd > table > tbody > tr > td { display: block; width: 100%; }
  .cockpit-bd > table > thead { display: none; }
  .cockpit-bd > table > tbody > tr {
    border: 1px solid var(--line); border-radius: 14px;
    padding: 12px 14px; margin: 0 0 10px; background: var(--card); box-shadow: var(--shadow);
  }
  .cockpit-bd > table > tbody > tr.mine     { box-shadow: inset 4px 0 0 var(--gold-deep), var(--shadow); }
  .cockpit-bd > table > tbody > tr.has-flag { box-shadow: inset 4px 0 0 var(--orange), var(--shadow); }
  .cockpit-bd > table > tbody > tr.row-changed { border-color: var(--purple-line); }
  .cockpit-bd > table > tbody > tr > td {
    display: flex; align-items: baseline; gap: 10px;
    padding: 4px 0; border: 0 !important; background: transparent !important;
  }
  .cockpit-bd > table > tbody > tr > td::before {
    content: attr(data-label);
    flex: 0 0 86px; font-size: 10.5px; font-weight: 700;
    text-transform: uppercase; letter-spacing: .04em; color: var(--muted);
  }
  /* Résumé : pleine largeur, mis en avant (le titre de la carte). */
  .cockpit-bd > table > tbody > tr > td[data-label="Résumé"] {
    display: block; font-size: 14.5px; font-weight: 600; color: var(--ink); padding: 2px 0 6px;
  }
  .cockpit-bd > table > tbody > tr > td[data-label="Résumé"]::before { display: block; margin-bottom: 3px; }
  /* Pastilles / chips : jamais étirées, jamais coupées. */
  .cockpit-bd > table > tbody > tr > td .pill,
  .cockpit-bd > table > tbody > tr > td .tag,
  .cockpit-bd > table > tbody > tr > td .k { white-space: nowrap; }

  /* ---- Tableaux denses des modales (fiche / activité / worklog) → cartes empilées ---- */
  .fiche-tbl > thead, .act-tbl > thead, .work-tbl > thead { display: none; }
  .fiche-tbl, .fiche-tbl > tbody, .fiche-tbl > tbody > tr, .fiche-tbl > tbody > tr > td,
  .act-tbl, .act-tbl > tbody, .act-tbl > tbody > tr, .act-tbl > tbody > tr > td,
  .work-tbl, .work-tbl > tbody, .work-tbl > tbody > tr, .work-tbl > tbody > tr > td { display: block; width: auto; }
  .fiche-tbl > tbody > tr, .act-tbl > tbody > tr, .work-tbl > tbody > tr {
    border: 1px solid var(--line); border-radius: 12px; padding: 10px 12px; margin: 0 0 9px;
  }
  .fiche-tbl > tbody > tr:nth-child(even) td, .act-tbl > tbody > tr:nth-child(even) td,
  .work-tbl > tbody > tr:nth-child(even) td { background: transparent; }
  .fiche-tbl > tbody > tr > td, .act-tbl > tbody > tr > td, .work-tbl > tbody > tr > td {
    border: 0 !important; padding: 2px 0 !important; width: auto !important;
  }
  .fiche-tbl .c-res, .act-tbl .c-act { font-weight: 600; color: var(--ink); }

  /* Plein écran fiable malgré la barre dynamique de Safari iOS. */
  .login-screen, .crash { min-height: 100dvh; }
}

/* Modales : démarrer sous la barre de statut (Dynamic Island) et au-dessus de l'indicateur d'accueil. */
@media (max-width: 768px) {
  .overlay { padding-top: calc(14px + env(safe-area-inset-top, 0px)); padding-bottom: calc(14px + env(safe-area-inset-bottom, 0px)); align-items: flex-start; }
  .install-ios { padding-bottom: calc(14px + env(safe-area-inset-bottom, 0px)); }
}

/* ===== CRA : encart récapitulatif d'import (Excel / CSV) ===== */
.cra-import-note { border: 1px solid var(--purple-line); background: var(--purple-soft); border-radius: 12px; padding: 11px 14px; margin-top: 16px; font-size: 12.5px; color: var(--ink); }
.cin-h { font-weight: 700; margin-bottom: 6px; }
.cin-cols { display: flex; flex-wrap: wrap; gap: 6px 16px; color: var(--body); }
.cin-cols b { color: var(--purple-strong); }
.cin-cols i { color: var(--muted); font-style: italic; }
.cin-warn { margin: 8px 0 0; padding-left: 18px; color: var(--orange-deep); }
.cin-warn li { margin: 3px 0; }

/* ===== Développeurs inactifs (aucun ticket depuis 6 mois) ===== */
.dev-row.inactive .dname { color: var(--muted); opacity: .75; }
.dev-inactive-tag { font-size: 10px; font-weight: 600; color: var(--orange-deep); background: var(--orange-soft); border: 1px solid #f6d8be; border-radius: 99px; padding: 1px 8px; margin-left: 8px; font-style: normal; white-space: nowrap; }

/* ===== Brief du matin : ligne d'état claire sous chaque ticket ===== */
.mb-state { font-size: 12px; color: var(--muted); margin-top: 2px; }
.mb-state b { color: var(--ink); font-weight: 700; }
.mb-state .late { color: var(--red); font-weight: 700; }

/* ===================== Navigation MOBILE : barre du bas + tiroir burger ===================== */
/* Cachés par défaut (ordinateur inchangé) ; activés sous 768px. */
.mobile-tabbar, .hdr-burger, .drawer, .drawer-backdrop, .enc-clienttabs { display: none; }

/* Styles du tiroir (le conteneur reste caché sur ordinateur via la règle ci-dessus). */
.drawer-hd { display: flex; align-items: center; justify-content: space-between; padding: 16px 18px; background: var(--hd-grad); color: #fff; font-weight: 700; font-size: 16px; box-shadow: inset 0 -2px 0 rgba(199,161,74,.6); }
.drawer-x { border: 0; background: rgba(255,255,255,.16); color: #fff; width: 32px; height: 32px; border-radius: 8px; font-size: 14px; cursor: pointer; }
.drawer-nav { display: flex; flex-direction: column; padding: 10px; gap: 4px; }
.drawer-item { display: flex; align-items: center; gap: 13px; border: 0; background: none; text-align: left; width: 100%; font-size: 15px; font-weight: 600; color: var(--ink); padding: 14px; border-radius: 12px; cursor: pointer; }
.drawer-item:active { background: var(--purple-soft); }
.drawer-item.active { background: var(--purple-soft); color: var(--purple-strong); }
.di-ic { width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; color: var(--muted); }
.drawer-item.active .di-ic { color: var(--purple-strong); }
.di-ic svg { width: 21px; height: 21px; }
.drawer-foot { margin-top: auto; padding: 16px 18px; font-size: 11px; color: var(--muted); border-top: 1px solid var(--line); }

@media (max-width: 768px) {
  /* La barre d'onglets du haut laisse place à la barre du bas + au burger. */
  .tabs { display: none; }
  .wrap { padding-bottom: calc(80px + env(safe-area-inset-bottom)); }
  /* On remonte les boutons flottants au-dessus de la barre du bas. */
  .to-top, .install-fab { bottom: calc(86px + env(safe-area-inset-bottom)); }
  .toast { bottom: calc(92px + env(safe-area-inset-bottom)); }

  /* ---- Burger (en-tête) ---- */
  .hdr-burger { display: inline-flex; align-items: center; justify-content: center; flex: 0 0 auto;
    width: 42px; height: 42px; margin-right: 11px; border: 1px solid rgba(255,255,255,.42);
    background: rgba(255,255,255,.18); color: #fff; border-radius: 11px; font-size: 20px; line-height: 1;
    cursor: pointer; box-shadow: 0 2px 8px rgba(20,18,40,.18); touch-action: manipulation; }
  .hdr-burger:active { background: rgba(255,255,255,.30); }

  /* ---- Barre du bas (4 onglets principaux) — bleue comme le header ---- */
  .mobile-tabbar { display: flex; position: fixed; left: 0; right: 0; bottom: 0; z-index: 40;
    background: var(--indigo-deep); border-top: 1px solid rgba(255,255,255,.10);
    padding: 5px 4px calc(5px + env(safe-area-inset-bottom));
    justify-content: space-around; align-items: stretch; box-shadow: 0 -6px 22px rgba(20,18,40,.30); }
  .mtab { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 4px;
    border: 0; background: none; color: rgba(255,255,255,.60); font-size: 11px; font-weight: 600;
    padding: 8px 2px 4px; border-radius: 12px; cursor: pointer; position: relative; min-height: 52px;
    -webkit-tap-highlight-color: transparent; touch-action: manipulation; }
  .mtab-ic { width: 23px; height: 23px; display: inline-flex; }
  .mtab-ic svg { width: 100%; height: 100%; }
  .mtab.active { color: #fff; }
  .mtab.active::before { content: ""; position: absolute; top: 0; left: 50%; transform: translateX(-50%);
    width: 28px; height: 3px; border-radius: 0 0 3px 3px; background: var(--gold); }
  .mtab-badge { position: absolute; top: 4px; left: calc(50% + 6px); background: var(--gold); color: var(--indigo-deep);
    font-size: 9px; font-weight: 800; min-width: 16px; height: 16px; border-radius: 9px;
    display: inline-flex; align-items: center; justify-content: center; padding: 0 4px; box-shadow: 0 0 0 2px var(--indigo-deep); }

  /* ---- Tiroir (glisse de la gauche) ---- */
  .drawer-backdrop { display: block; position: fixed; inset: 0; z-index: 199; background: rgba(20,18,40,.42);
    opacity: 0; pointer-events: none; transition: opacity .25s ease; }
  .drawer-backdrop.show { opacity: 1; pointer-events: auto; }
  .drawer { display: flex; flex-direction: column; position: fixed; top: 0; bottom: 0; left: 0; z-index: 200;
    width: 80%; max-width: 320px; background: #fff; box-shadow: 6px 0 34px rgba(20,18,40,.32);
    transform: translateX(-100%); transition: transform .27s ease;
    padding-top: env(safe-area-inset-top); padding-bottom: env(safe-area-inset-bottom); }
  .drawer.open { transform: translateX(0); }

  /* ---- En cours : onglets clients (accès rapide + scroll auto) ---- */
  .enc-clienttabs { display: flex; gap: 7px; overflow-x: auto; -webkit-overflow-scrolling: touch;
    scrollbar-width: none; padding: 2px 0 10px; margin-top: 2px; }
  .enc-clienttabs::-webkit-scrollbar { display: none; }
  .enc-ctab { flex: 0 0 auto; display: inline-flex; align-items: center; gap: 6px;
    border: 1px solid var(--purple-line); background: var(--card); color: var(--ink);
    font-weight: 700; font-size: 13px; padding: 8px 13px; border-radius: 99px; cursor: pointer; white-space: nowrap; }
  .enc-ctab:active { background: var(--purple-soft); }
  .enc-ctab-n { font-size: 11px; font-weight: 800; color: #fff; background: var(--indigo);
    border-radius: 99px; padding: 0 7px; min-width: 18px; text-align: center; }
  .enc-card { scroll-margin-top: 14px; }

  /* ---- Développeurs : « Charge par développeur » sur 2 lignes claires ---- */
  .dev-list { gap: 10px; }
  .dev-row { flex-wrap: wrap; align-items: center; row-gap: 8px; padding: 12px; border: 1px solid var(--line-soft); border-radius: 12px; }
  .dev-name { flex: 1 1 100%; min-width: 0; font-size: 14px; }
  .dev-bar { display: none; }
  .dev-counts { flex: 1 1 100%; justify-content: flex-start; gap: 6px; flex-wrap: wrap; }
  .dev-counts .dev-hide, .dev-counts .dev-caret { flex: 0 0 auto; }
  .dev-caret { margin-left: auto; }
}

/* ===== En-tête : nom de page (caché par défaut → ordinateur & dashboard inchangés) ===== */
.hdr-page { display: none; }

@media (max-width: 768px) {
  /* Sous-pages mobile : header compact qui s'arrête sous la ligne « Données au … ».
     On masque les indicateurs (Total / À faire / En cours / Bloqués / En retard / Terminés)
     + la barre d'avancement + le gros titre, et on affiche le NOM DE LA PAGE. */
  .hdr.is-sub .kpis,
  .hdr.is-sub .progress { display: none; }
  .hdr.is-sub .hdr-title { display: none; }
  .hdr.is-sub .hdr-page { display: block; font-size: 21px; font-weight: 800; color: #fff; letter-spacing: .01em; margin-top: 4px; }
  .hdr.is-sub { padding-bottom: 14px; }

  /* ===== Fluidité mobile : supprime le délai de tap + ne peint que ce qui est visible ===== */
  button, a, .tab, .mtab, .drawer-item, .enc-ctab, [role="button"] { touch-action: manipulation; }
  .cockpit-bd > table > tbody > tr { content-visibility: auto; contain-intrinsic-size: auto 150px; }
  .enc-card { content-visibility: auto; contain-intrinsic-size: auto 320px; }
  .dev-row { content-visibility: auto; contain-intrinsic-size: auto 84px; }
  .recap-card, .pcard { content-visibility: auto; contain-intrinsic-size: auto 260px; }
}

/* ===================== Vue Recette (reste à recetter / à retravailler) ===================== */
.rec-card { background: var(--card, #fff); border: 1px solid var(--line); border-radius: 16px; padding: 16px 18px; margin-bottom: 14px; box-shadow: var(--shadow); }
.rec-hd { display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap; }
.rec-name { font-size: 17px; font-weight: 800; color: var(--ink); }
.rec-metrics { display: flex; gap: 18px; flex-wrap: wrap; }
.rec-m { display: flex; flex-direction: column; align-items: center; line-height: 1.05; }
.rec-m b { font-size: 22px; font-weight: 800; color: var(--ink); }
.rec-m small { font-size: 10px; color: var(--muted); text-transform: uppercase; letter-spacing: .04em; margin-top: 2px; }
.rec-m.rec-big b { color: var(--purple-strong); }
.rec-m.rec-rew b { color: var(--orange-deep); }
.rec-m.rec-done b { color: #1f7a44; }
.rec-chips { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 14px; }
.rec-chip { display: inline-flex; align-items: center; gap: 6px; font-size: 11.5px; font-weight: 600; padding: 3px 9px; border-radius: 99px; background: #f1f0f6; color: var(--ink); border: 1px solid var(--line); }
.rec-chip b { font-weight: 800; }
.rec-chip.cat-encours { background: #eef0ff; color: #3a3d9e; border-color: #dcdcfb; }
.rec-chip.cat-retourTest, .rec-chip.cat-retourProd { background: var(--orange-soft); color: var(--orange-deep); border-color: #f6d8be; }
.rec-chip.cat-recetteArmonie, .rec-chip.cat-recetteClient { background: #fbf2dc; color: #8a6a1e; border-color: #efe0b8; }
.rec-chip.cat-attenteClient { background: #fff4e6; color: #9a5a12; border-color: #f6dcb8; }
.rec-chip.cat-miseEnProd, .rec-chip.cat-termine { background: #e3f6ea; color: #1f7a44; border-color: #c7ecd5; }
.rec-chip.cat-annule { background: #f3f3f5; color: #9a98a8; border-color: var(--line); text-decoration: line-through; }
.rec-rework { margin-top: 12px; border-top: 1px solid var(--line-soft); padding-top: 10px; }
.rec-rew-tg { border: 0; background: none; color: var(--orange-deep); font-weight: 700; font-size: 13px; cursor: pointer; padding: 2px 0; }
.rec-rew-list { list-style: none; margin: 8px 0 0; padding: 0; display: flex; flex-direction: column; gap: 6px; }
.rec-rew-list li { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; padding: 8px 10px; border: 1px solid var(--line); border-radius: 10px; cursor: pointer; background: #fff; }
.rec-rew-list li:hover { background: var(--purple-soft); }
.rr-res { flex: 1; min-width: 120px; font-size: 13px; color: var(--ink); }

/* ===================== Fiche ticket : chaîne de statuts ===================== */
.status-chain { background: var(--purple-soft); border: 1px solid var(--purple-line); border-radius: 12px; padding: 11px 14px; margin: 0 0 12px; }
.sc-h { font-size: 12px; font-weight: 700; color: var(--purple-strong); margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
.sc-flag { font-size: 10px; font-weight: 800; color: var(--orange-deep); background: var(--orange-soft); border: 1px solid #f6d8be; border-radius: 99px; padding: 1px 8px; }
.sc-path { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; }
.sc-seg { display: inline-flex; align-items: center; gap: 6px; }
.sc-arrow { color: var(--muted); font-weight: 700; }
.sc-step { font-size: 12px; font-weight: 600; color: var(--ink); background: #fff; border: 1px solid var(--line); border-radius: 99px; padding: 3px 10px; white-space: nowrap; }
.sc-step.is-retour { background: var(--orange-soft); color: var(--orange-deep); border-color: #f6d8be; }
.sc-step.is-now { box-shadow: 0 0 0 2px var(--purple-line); font-weight: 800; }
.sc-note { font-size: 11.5px; color: var(--orange-deep); margin-top: 8px; }

@media (max-width: 768px) { .rec-card { content-visibility: auto; contain-intrinsic-size: auto 230px; } }

/* Chaîne de statuts — durées + clés « où ça a coincé » */
.sc-step .sc-dur { margin-left: 6px; font-size: 10px; font-weight: 700; color: var(--muted); }
.sc-step.is-retour .sc-dur { color: var(--orange-deep); }
.sc-clues { margin-top: 10px; border-top: 1px dashed var(--purple-line); padding-top: 8px; }
.scc-h { font-size: 11px; font-weight: 800; color: var(--orange-deep); text-transform: uppercase; letter-spacing: .04em; margin-bottom: 5px; }
.scc-line { font-size: 12.5px; color: var(--ink); margin: 3px 0; }
.scc-dot { color: var(--orange-deep); font-weight: 800; margin-right: 4px; }
.scc-tip { font-size: 11px; color: var(--muted); font-style: italic; margin-top: 6px; }

/* ===== KPI du header cliquables (ordinateur) — apparence IDENTIQUE à l'origine, simplement cliquable ===== */
button.kpi { appearance: none; -webkit-appearance: none; font: inherit; color: inherit; text-align: left; width: 100%; cursor: pointer; }

/* Sous-titre du header (plus petit que « Welcome to the jungle ! ») */
.hdr-tagline {
  font-family: "Poppins", sans-serif;   /* même typo que le « cp » de la marque */
  font-style: italic;                    /* « we take it day-by-day ! » en italique */
  font-weight: 800;
  font-size: .52em;
  margin-left: .14em;
  letter-spacing: .005em;
  white-space: nowrap;
  /* même dégradé que « WIRE », appliqué sur le texte */
  background: var(--wire-grad);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  -webkit-text-fill-color: transparent; /* indispensable sur iOS / Safari (PWA iPhone) */
}

/* Badge d'engagement client : TMA / Projet / mixte */
.eng-badge { display: inline-block; font-size: 10.5px; font-weight: 800; letter-spacing: .03em; padding: 2px 9px; border-radius: 999px; vertical-align: middle; }
.eng-badge.is-tma { background: var(--purple-soft); color: var(--purple-strong); border: 1px solid var(--purple-line); }
.eng-badge.is-projet { background: var(--orange-soft); color: var(--orange-deep); border: 1px solid #f0d2b0; }
.eng-badge.is-mix { background: #eef3ff; color: #3a5bd0; border: 1px solid #d4e0ff; }
.pcard .eng-badge { margin-top: 3px; }
.rec-hd .eng-badge { margin-left: 8px; }

/* ===== Bouton + modale « CR du jour » ===== */
.owner-bar { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
.cr-day-btn { font-weight: 700; }
.cr-modal { max-width: 980px; width: 96vw; }
.cr-modal .cr-sub { font-size: 12px; color: var(--muted); margin-top: 2px; }
.cr-body { padding: 16px 20px 20px; }
.cr-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; }
.cr-hint { font-size: 12.5px; color: var(--muted); margin: 0 0 10px; line-height: 1.5; }
.cr-msg { background: var(--purple-soft); border: 1px solid var(--purple-line); color: var(--purple-strong); border-radius: 10px; padding: 8px 12px; font-size: 13px; margin-bottom: 10px; }
.cr-preview-wrap { border: 1px solid var(--line); border-radius: 12px; overflow: hidden; background: #fff; }
.cr-preview { width: 100%; height: 460px; border: 0; display: block; background: #fff; }
@media (max-width: 768px) { .cr-preview { height: 58vh; } .cr-modal { width: 100vw; } }
.cr-pick { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; }
.cr-pick label { font-size: 13px; color: var(--muted); font-weight: 600; }
.cr-pick select { padding: 6px 10px; border: 1px solid var(--line); border-radius: 8px; font: inherit; background: #fff; }

/* ============================================================
   REFONTE MOBILE — thème navy + orange (≤768px UNIQUEMENT)
   Tout est ici, sous le media query : le DESKTOP n'est jamais impacté.
   ============================================================ */
@media (max-width: 768px) {
  /* 1) Tokens repeints en navy (cascade sur toute l'appli mobile) */
  :root {
    --bg: #0e1322; --bg-top: #141a2e;
    --card: #192036; --card-2: #1d2540;
    --line: rgba(255,255,255,.08); --line-soft: rgba(255,255,255,.05); --row-alt: #1d2540;
    --ink: #eef1f8; --body: #e4e8f3; --muted: #8b93ad;
    --hd-grad: linear-gradient(180deg, #141a2e, #0e1322 70%);
    --orange: #f97316; --orange-deep: #f2700f; --orange-soft: rgba(249,115,22,.16);
    --purple: #8b7cf6; --purple-strong: #a99bff; --purple-soft: rgba(139,124,246,.16); --purple-line: rgba(139,124,246,.30);
    --gold: #f5a623; --gold-deep: #d98a12;
    --green: #34d399; --green-bg: rgba(52,211,153,.16);
    --blue: #4f8ff7; --blue-bg: rgba(79,143,247,.16);
    --amber: #f5a623; --amber-bg: rgba(245,166,35,.16);
    --red: #f06a72; --red-bg: rgba(240,106,114,.16);
    --shadow: 0 1px 2px rgba(0,0,0,.40), 0 10px 26px rgba(0,0,0,.34);
    --shadow-lg: 0 18px 50px rgba(0,0,0,.55);
  }
  body { background: var(--bg); color: var(--ink); }

  /* 2) Contrôles/cartes à fond blanc codé en dur → carte navy + texte clair */
  .fbtn, .fselect, .btn-line, .dev-block, .dstat, .meet-card, .enc-card, .cra-card, .cra-kpi,
  table.edit-tbl input, table.edit-tbl select, .cra-form input, .cra-form select, .cra-form input[type="date"],
  .search-suggest, .rec-rew-list li, .sc-step, .part-del, .dev-hide, .notif-panel,
  .filter-box-bd { background: var(--card); color: var(--ink); border-color: var(--line); }
  .rec-chip.cat-attenteClient { background: var(--amber-bg); color: var(--amber); border-color: rgba(245,166,35,.32); }

  /* 3) En-tête : bande navy continue + recherche sombre */
  .hdr-search input { background: var(--card-2); color: var(--ink); border: 1px solid var(--line); }
  .hdr-search input::placeholder { color: var(--muted); }
  .hdr-burger { border-color: rgba(255,255,255,.16); background: rgba(255,255,255,.06); }

  /* 4) KPI → cartes « stat » navy, chiffres colorés par statut */
  .kpis .kpi { background: var(--card); border: 1px solid var(--line); border-radius: 18px; padding: 14px; }
  .kpis .kpi .lbl { color: var(--muted); }
  .kpis .kpi .val { color: var(--ink); }
  .kpis .kpi:first-child .val { color: var(--purple-strong); }
  .kpi.todo .val { color: #ff9f4a; }
  .kpi.prog .val { color: #6ba4ff; }
  .kpi.block .val { color: #ff7d85; }
  .kpi.late .val { color: #f5b53e; }
  .kpi.done .val { color: #4ade9f; }

  /* 5) Bouton Actualiser → orange plein */
  .reload-btn, .reload-btn:hover { background: linear-gradient(180deg,#fb8a3a,#f2700f); color: #fff; border: 0;
    box-shadow: 0 10px 24px -12px rgba(249,115,22,.72); transform: none; }
  .reload-btn .reload-ico, .reload-btn .reload-txt { color: #fff; }

  /* 6) Barre du bas → navy + onglet actif ORANGE avec halo */
  .mobile-tabbar { background: var(--bg-top); border-top: 1px solid var(--line);
    box-shadow: 0 -6px 22px rgba(0,0,0,.45); }
  .mtab { color: var(--muted); }
  .mtab.active { color: var(--orange); }
  .mtab.active::before { background: var(--orange); box-shadow: 0 0 10px var(--orange); border-radius: 99px; }

  /* 7) Tiroir (drawer) → sombre + élément actif orange */
  .drawer { background: linear-gradient(180deg, #141a2e, #0e1322); border-right: 1px solid var(--line); }
  .drawer-item { color: var(--muted); }
  .drawer-item:active { background: rgba(255,255,255,.05); }
  .drawer-item.active { background: rgba(249,115,22,.12); color: var(--orange); }
  .drawer-item.active .di-ic { color: var(--orange); }
  .drawer-foot { border-top: 1px solid var(--line); color: var(--muted); }

  /* 8) Onglets clients (En cours) + pastille compteur → accent navy/orange */
  .enc-ctab { border-color: var(--line); }
  .enc-ctab-n { background: var(--orange); color: #fff; }
}

/* ============================================================
   EN-TÊTE RESTRUCTURÉ — barre du haut propre
   (marque à gauche · recherche/Actualiser/cloche/déconnexion à droite, même ligne)
   ============================================================ */
/* Ordinateur : tout sur UNE ligne, aucun enroulement */
.hdr-top { display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: nowrap; position: relative; }
.hdr-brand { display: flex; align-items: center; gap: 10px; min-width: 0; flex: 0 0 auto; overflow: visible; }
.hdr-logo { height: 26px; width: auto; display: block; margin: 0; flex: 0 0 auto; }
.eyebrow { display: inline-flex; align-items: center; gap: 8px; width: auto; text-align: left; white-space: nowrap; }
.hdr-controls { display: flex; align-items: center; justify-content: flex-end; gap: 8px; flex-wrap: nowrap; flex: 1 1 auto; min-width: 0; }
.hdr-controls .btn { height: 40px; flex: 0 0 auto; }
.hdr-controls .hdr-search { flex: 1 1 0; min-width: 90px; max-width: 240px; width: auto; }
.hdr-headline { display: flex; align-items: flex-end; justify-content: space-between; gap: 16px; margin-top: 14px; position: relative; }
.hdr-headline .hdr-left { min-width: 0; }
.hdr-headline .src { text-align: right; flex: 0 0 auto; white-space: nowrap; }

/* ---- Nettoyage du header mobile : lignes claires, pas de fouillis ---- */
@media (max-width: 768px) {
  .hdr-top { flex-wrap: wrap; gap: 10px; }
  .hdr-brand { flex: 1 1 auto; overflow: visible; }
  .eyebrow { flex-wrap: wrap; white-space: normal; row-gap: 4px; }   /* le badge BUILD passe à la ligne au lieu de déborder */
  .hdr-build { margin-left: 0; }
  .hdr-logo { height: 22px; }
  .hdr-controls { flex: 1 1 100%; flex-wrap: wrap; justify-content: space-between; gap: 8px; }
  .hdr-controls .hdr-search { flex: 1 1 100%; width: 100%; max-width: none; order: -1; }   /* recherche pleine largeur, sa propre ligne */
  .hdr-controls .gauge-btn { flex: 1 1 auto; }
  .hdr-logout { display: none; }                                          /* la déconnexion est déjà dans le tiroir */
  .hdr-headline { flex-direction: column; align-items: flex-start; gap: 4px; margin-top: 10px; }
  .hdr-headline .src { text-align: left; white-space: normal; font-size: 11px; }
}

/* Sécurité : sur les écrans étroits (petits portables), on masque le badge BUILD
   pour laisser de la place aux contrôles — il reste visible dès 1100px. */
@media (min-width: 769px) and (max-width: 1100px) {
  .hdr-build { display: none; }
}

/* ============================================================
   MOBILE UNIQUEMENT — « Inviter » et le bandeau d'import orange
   ne s'affichent que sur la page Cockpit.
   (Desktop totalement inchangé : tout est sous @media max-width:768px.)
   ============================================================ */
@media (max-width: 768px) {
  .owner-bar { margin-top: 0; }                                /* pas d'espace vide en haut sur mobile */
  /* masqués par défaut sur mobile (toutes les pages) */
  .invite-btn { display: none; }
  .import-warning { display: none; }
  /* réaffichés uniquement sur la page Cockpit */
  .tab-cockpit .invite-btn { display: inline-flex; }
  .tab-cockpit .import-warning { display: block; }
}

/* ============================================================
   Badge BUILD : en haut à gauche sur ORDINATEUR,
   reporté sur la ligne « Données au… » en MOBILE
   (et « Cockpit de pilotage » reste sur la ligne du logo)
   ============================================================ */
.hdr-build-src { display: none; }
@media (max-width: 768px) {
  .eyebrow { white-space: nowrap; }            /* intitulé sur une ligne, avec le logo */
  .eyebrow .hdr-build { display: none; }       /* on retire le badge de sous l'intitulé */
  .hdr-build-src { display: inline-block; margin-left: 8px; }   /* il rejoint « Données au… » */
}

/* ============================================================
   MOBILE — corrige les fonds clairs résiduels (texte clair illisible).
   On assombrit uniquement les éléments qui avaient fond clair + texte clair ;
   ceux qui ont déjà un texte foncé (badges colorés, .banner…) ne sont pas touchés.
   ============================================================ */
@media (max-width: 768px) {
  .period-sum,
  .invite-note,
  .recap-desc { background: rgba(255,255,255,.06); color: var(--ink); border-color: var(--line); }
  .drop { background: rgba(255,255,255,.05); color: var(--muted); border-color: var(--line); }
  tr.mine td { background: rgba(199,161,74,.10); }
  .dstat.todo  { background: rgba(199,161,74,.14); border-color: rgba(199,161,74,.32); color: var(--ink); }
  .dstat.block { background: rgba(224,108,108,.16); border-color: rgba(224,108,108,.34); color: var(--ink); }
  .wk-off, .wk-load { background: rgba(255,255,255,.06); color: var(--muted); }
  .rec-chip { background: rgba(255,255,255,.07); color: var(--ink); border-color: var(--line); }
  .crash-card, .install-ios-box { background: var(--card); color: var(--ink); border-color: var(--line); }
}

/* ============================================================
   MOBILE PWA UNIQUEMENT (≤768px) — ajustements demandés.
   Le DESKTOP n'est jamais impacté : tout est sous ce media query.
   ============================================================ */
@media (max-width: 768px) {
  /* 1) Titres de section ("Récap de la journée"…) : même typo que le
        titre de page ("Récap du jour") = Inter, gras 800. */
  .section-title { font-family: "Inter", system-ui, -apple-system, sans-serif; font-weight: 800; }

  /* 2) Conteneur "Explication simple" (fiche ticket) : violet + écriture blanche.
        Violet profond choisi pour rester lisible sur le thème sombre. */
  .expl { background: #5a48b0; border-color: #6e5cc4; }
  .expl-h { color: rgba(255,255,255,.9); }
  .expl p { color: #fff; }

  /* 3) Barre "Exporter / partager" : libellé sur sa ligne, puis les 4 boutons
        (PDF · Télécharger · Copier · E-mail) harmonisés en grille 2×2 égale. */
  .export-bar { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; align-items: stretch; }
  .export-bar .eb-lbl { grid-column: 1 / -1; }
  .export-bar .btn-line { width: 100%; text-align: center; }
  .export-bar .eb-err { grid-column: 1 / -1; }
}

/* ---- Localisation programme (référentiel Arcad, à côté de chaque ticket) ---- */
.prog-loc { background: var(--card); border: 1px solid var(--line); border-left: 3px solid var(--gold); border-radius: 12px; padding: 12px 16px; margin: 4px 0 16px; }
.prog-loc.nf { border-left-color: var(--line); opacity: .92; }
.prog-h { font-weight: 700; font-size: 11px; letter-spacing: .07em; text-transform: uppercase; color: var(--gold-deep); margin-bottom: 8px; }
.prog-loc.nf .prog-h { color: var(--muted); }
.prog-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px 18px; }
.pl-cell { display: flex; flex-direction: column; gap: 1px; min-width: 0; }
.pl-l { font-size: 10.5px; letter-spacing: .04em; text-transform: uppercase; color: var(--muted); }
.pl-v { font-size: 14px; color: var(--ink); font-weight: 600; word-break: break-word; }
.mono { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }
.prog-src { margin: 8px 0 0; font-size: 11px; color: var(--muted); }
.prog-chip { display: inline-block; margin-left: 6px; font-size: 10.5px; font-weight: 600; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; color: var(--gold-deep); background: var(--gold-soft, #f8f1dd); border: 1px solid #ecd9a8; border-radius: 5px; padding: 1px 6px; vertical-align: middle; white-space: nowrap; }

/* ---- Onglet SLA (pilotage des engagements) ---- */
.sla-wrap { display: block; }
.sla-intro { padding: 4px 2px; }
.sla-intro code, .sla-note code { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 12.5px; background: var(--line-soft); padding: 1px 5px; border-radius: 4px; }
.sla-kpis { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; margin: 8px 0 16px; }
.sla-kpi { background: var(--card); border: 1px solid var(--line); border-radius: 12px; padding: 12px 14px; text-align: center; }
.sla-kpi .v { font-size: 26px; font-weight: 800; line-height: 1.1; color: var(--ink); }
.sla-kpi .l { font-size: 11px; color: var(--muted); margin-top: 4px; }
.sla-ok { color: #2e9e5b !important; }
.sla-warn { color: #c98a1e !important; }
.sla-bad { color: #d1495b !important; }
.sla-h { margin: 18px 0 8px; font-size: 14px; font-weight: 700; color: var(--ink); }
.sla-list { display: flex; flex-direction: column; gap: 6px; }
.sla-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; background: var(--card); border: 1px solid var(--line); border-left: 3px solid var(--line); border-radius: 10px; padding: 8px 12px; cursor: pointer; }
.sla-row:hover { background: var(--line-soft); }
.sla-bad-row { border-left-color: #d1495b; }
.sla-warn-row { border-left-color: #c98a1e; }
.sla-prio { font-size: 10.5px; font-weight: 700; color: var(--muted); border: 1px solid var(--line); border-radius: 5px; padding: 1px 6px; }
.sla-resume { flex: 1 1 220px; min-width: 0; font-size: 13.5px; color: var(--ink); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.sla-late { font-size: 12px; color: var(--muted); white-space: nowrap; }
.sla-bad-row .sla-late b { color: #d1495b; }
.muted-cell { color: var(--muted); }
.sla-note { margin-top: 16px; font-size: 12px; color: var(--muted); line-height: 1.5; }
@media (max-width: 768px) {
  .sla-kpis { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .sla-resume { flex-basis: 100%; white-space: normal; }
}

/* Note de cadrage "sur la période" dans les CR */
.cr-scope { font-size: 12px; color: var(--muted); margin: -2px 0 6px; }

/* Listes compactes des états des lieux (N° — description — intervenant — état) */
.cr-list { margin: 4px 0 14px; padding-left: 18px; }
.cr-list li { font-size: 13px; line-height: 1.5; margin: 2px 0; color: var(--ink); }
.cr-list li .who { color: var(--purple-strong, #5a48b0); font-weight: 600; }
.cr-tk-who { font-size: 12px; color: var(--muted); font-weight: 600; margin-left: 6px; }

/* Contrôle qualité Jira — accordéon d'anomalies */
.hyg-drow { cursor: pointer; transition: background .12s; }
.hyg-drow:hover { background: var(--purple-soft, #f3eafe); }
.hyg-drow.on { background: var(--purple-soft, #f3eafe); box-shadow: inset 3px 0 0 var(--purple, #6e5cc4); }
.hyg-grp-wrap { margin-bottom: 2px; }
.hyg-grp { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .03em; color: var(--indigo, #3b327a); margin: 9px 0 3px; }
.hyg-grp span { color: var(--muted, #8a87a0); font-weight: 600; }
.hyg-filter { font-size: 12px; font-weight: 600; color: #6e5cc4; background: var(--purple-soft, #f3eafe); border-radius: 999px; padding: 2px 4px 2px 11px; margin-left: 8px; display: inline-flex; align-items: center; gap: 5px; vertical-align: middle; }
.hyg-filter button { border: 0; background: rgba(0,0,0,.10); color: inherit; border-radius: 50%; width: 18px; height: 18px; cursor: pointer; line-height: 1; font-size: 11px; padding: 0; }
.hyg-filter button:hover { background: rgba(0,0,0,.2); }
.hyg-checks { display: flex; flex-direction: column; gap: 8px; margin: 8px 0 14px; }
.hyg-check { border: 1px solid var(--line, #e7e5f1); border-radius: 10px; overflow: hidden; background: var(--card, #fff); }
.hyg-head { display: flex; align-items: center; gap: 10px; padding: 10px 12px; cursor: pointer; }
.hyg-head:hover { background: var(--hover, #faf9fe); }
.hyg-count { min-width: 28px; text-align: center; font-weight: 800; font-family: 'Poppins', sans-serif; background: #f3eafe; color: #6e5cc4; border-radius: 7px; padding: 2px 7px; }
.hyg-label { font-weight: 600; flex: 1; }
.hyg-toggle { color: var(--muted, #74718a); font-size: 12px; }
.hyg-hint { font-size: 11.5px; color: var(--muted, #74718a); padding: 0 12px 9px 50px; margin-top: -3px; }

/* ===================== Suivi de projets ===================== */
.pf-wrap { display: flex; flex-direction: column; gap: 18px; }
.pf-hero { background: var(--hd-grad); color: #fff; border-radius: 16px; padding: 20px 24px; box-shadow: var(--shadow); }
.pf-hero h2 { margin: 0; font-size: 22px; font-weight: 800; font-family: "Poppins", sans-serif; }
.pf-hero p { margin: 4px 0 0; color: #d9d3f0; font-size: 13px; }

.pf-kpis { display: grid; grid-template-columns: repeat(6, 1fr); gap: 12px; }
.pf-kpi { background: var(--card); border: 1px solid var(--line); border-radius: 14px; padding: 14px 16px; box-shadow: var(--shadow); position: relative; overflow: hidden; }
.pf-kpi::before { content: ""; position: absolute; left: 0; top: 0; bottom: 0; width: 4px; }
.pf-kpi.t-i::before { background: var(--purple); }
.pf-kpi.t-g::before { background: var(--gold); }
.pf-kpi.t-o::before { background: var(--orange); }
.pf-kpi-v { font-size: 20px; font-weight: 800; color: var(--ink); font-family: "Poppins", sans-serif; }
.pf-kpi-l { font-size: 11px; color: var(--muted); text-transform: uppercase; letter-spacing: .03em; margin-top: 2px; }

.pf-pipe { display: flex; gap: 8px; }
.pf-pipe-seg { flex: 1; border-radius: 12px; padding: 11px 13px; color: #fff; display: flex; flex-direction: column; gap: 1px; box-shadow: var(--shadow); }
.pf-pipe-seg b { font-size: 21px; font-weight: 800; line-height: 1; font-family: "Poppins", sans-serif; }
.pf-pipe-seg span { font-size: 11px; font-weight: 600; opacity: .96; }
.pf-pipe-seg i { font-size: 10px; opacity: .82; font-style: normal; }
.pf-pipe-seg.pf-av { background: #9b97b3; }
.pf-pipe-seg.pf-pr { background: var(--orange); }
.pf-pipe-seg.pf-si { background: var(--gold); }
.pf-pipe-seg.pf-en { background: var(--purple); }
.pf-pipe-seg.pf-te { background: var(--green); }

.pf-client { background: var(--card); border: 1px solid var(--line); border-radius: 16px; padding: 16px 18px; box-shadow: var(--shadow); }
.pf-client-hd { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; border-bottom: 1px solid var(--line-soft); padding-bottom: 12px; margin-bottom: 14px; }
.pf-client-id { display: flex; align-items: center; gap: 8px; }
.pf-client-id h3 { margin: 0; font-size: 17px; font-weight: 800; color: var(--ink); font-family: "Poppins", sans-serif; }
.pf-client-fin { display: flex; gap: 18px; margin-left: auto; }
.pf-client-fin div { display: flex; flex-direction: column; }
.pf-client-fin span { font-size: 10px; color: var(--muted); text-transform: uppercase; letter-spacing: .02em; }
.pf-client-fin b { font-size: 14px; color: var(--ink); }
.pf-pulse { display: flex; gap: 6px; flex-wrap: wrap; flex-basis: 100%; }
.pf-chip { font-size: 11px; font-weight: 600; padding: 3px 9px; border-radius: 999px; background: var(--purple-soft); color: var(--purple-strong); }
.pf-chip.act { background: var(--blue-bg); color: var(--blue); }
.pf-chip.rec { background: var(--amber-bg); color: var(--amber); }
.pf-chip.ret { background: var(--red-bg); color: var(--red); }
.pf-chip.late { background: var(--red-bg); color: var(--red); }

.pf-recette { display: flex; align-items: center; gap: 10px; margin-bottom: 14px; font-size: 12px; flex-wrap: wrap; }
.pf-recette-lb { font-weight: 700; color: var(--purple-strong); white-space: nowrap; }
.pf-recette-bar { flex: 1; height: 8px; background: var(--line); border-radius: 99px; overflow: hidden; max-width: 280px; min-width: 120px; }
.pf-recette-bar div { height: 100%; background: linear-gradient(90deg, var(--purple), var(--gold)); }
.pf-recette-pct { font-weight: 800; color: var(--ink); }
.pf-recette-meta { color: var(--muted); }

.pf-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(290px, 1fr)); gap: 12px; }
.pf-card { border: 1px solid var(--line); border-radius: 14px; padding: 12px 14px; background: var(--card); display: flex; flex-direction: column; gap: 9px; transition: box-shadow .15s, transform .15s; }
.pf-card:hover { box-shadow: var(--shadow); transform: translateY(-1px); }
.pf-card-top { display: flex; align-items: center; gap: 7px; }
.pf-etat { font-size: 11px; font-weight: 700; padding: 2px 9px; border-radius: 999px; }
.pf-etat.pf-en { background: var(--purple-soft); color: var(--purple-strong); }
.pf-etat.pf-si { background: #f7efd9; color: #8a6d1f; }
.pf-etat.pf-pr { background: var(--orange-soft); color: var(--orange-deep); }
.pf-etat.pf-av { background: var(--line-soft); color: var(--muted); }
.pf-etat.pf-te { background: var(--green-bg); color: var(--green); }
.pf-type { font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 6px; background: var(--blue-bg); color: var(--blue); }
.pf-type.tma { background: var(--orange-soft); color: var(--orange-deep); }
.pf-meteo { width: 12px; height: 12px; border-radius: 50%; margin-left: auto; box-shadow: 0 0 0 3px rgba(0,0,0,.04); }
.pf-card-body { display: flex; gap: 12px; align-items: center; }
.pf-ring { width: 44px; height: 44px; flex: none; }
.pf-ring-t { font-size: 12px; font-weight: 800; fill: var(--ink); font-family: "Poppins", sans-serif; }
.pf-card-h { min-width: 0; }
.pf-nom { font-weight: 700; color: var(--ink); font-size: 14px; line-height: 1.2; }
.pf-perim { font-size: 12px; color: var(--body); margin-top: 1px; }
.pf-num { font-size: 11px; color: var(--muted); margin-top: 2px; }
.pf-fin { display: flex; gap: 6px; border-top: 1px solid var(--line-soft); padding-top: 8px; }
.pf-fin div { flex: 1; display: flex; flex-direction: column; }
.pf-fin span { font-size: 9.5px; color: var(--muted); text-transform: uppercase; }
.pf-fin b { font-size: 12.5px; color: var(--ink); }
.pf-fin b.neg { color: var(--red); }
.pf-att { margin: 0; padding: 0; list-style: none; display: flex; flex-direction: column; gap: 3px; }
.pf-att li { font-size: 11.5px; color: var(--amber); background: var(--amber-bg); border-radius: 7px; padding: 4px 8px; }
.pf-att li::before { content: "\26A0  "; }
.pf-raf { margin: 0; padding-left: 18px; display: flex; flex-direction: column; gap: 2px; }
.pf-raf li { font-size: 11.5px; color: var(--body); }
.pf-com { font-size: 11px; color: var(--muted); font-style: italic; }
.pf-foot { font-size: 11px; color: var(--muted); text-align: center; margin-top: 6px; }

@media (max-width: 760px) {
  .pf-kpis { grid-template-columns: repeat(2, 1fr); }
  .pf-pipe { flex-wrap: wrap; }
  .pf-pipe-seg { flex-basis: calc(50% - 4px); }
  .pf-client-fin { margin-left: 0; }
  .pf-grid { grid-template-columns: 1fr; }
}
