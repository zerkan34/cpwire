import React, { useState } from "react";

const PILL = { Bloqué: "block", "À faire": "todo", "En cours": "prog", Terminé: "done" };
const STATUT_ORDER = { Bloqué: 0, "À faire": 1, "En cours": 2, Terminé: 3 };

function fmtDate(s) {
  if (!s) return "";
  try { return new Date(s).toLocaleDateString("fr-FR"); } catch { return s; }
}

function prioClass(p) {
  const x = (p || "").toLowerCase();
  if (/haut|high|criti|urgen|bloqu/.test(x)) return "p-haute";
  if (/moy|medium|normal/.test(x)) return "p-moyenne";
  if (/bas|low|mineur|minor|trivial/.test(x)) return "p-basse";
  return "";
}
// Rang numérique de priorité (0 = plus haute) pour le tri.
function prioRank(p) {
  const c = prioClass(p);
  return c === "p-haute" ? 0 : c === "p-moyenne" ? 1 : c === "p-basse" ? 2 : 3;
}

// Colonnes triables (clé d'accès + façon de comparer).
const COLS = [
  { key: "cle", label: "Clé", get: (r) => r.cle, type: "text" },
  { key: "dossier", label: "Dossier", get: (r) => r.dossier, type: "text" },
  { key: "resume", label: "Résumé", get: (r) => r.resume, type: "text" },
  { key: "assigne", label: "Sur le ticket", get: (r) => (r.contributors && r.contributors.length ? r.contributors[0] : r.assigne || ""), type: "text" },
  { key: "echeance", label: "Échéance", get: (r) => r.echeance || "", type: "date" },
  { key: "priorite", label: "Priorité", get: (r) => prioRank(r.priorite), type: "num" },
  { key: "statut", label: "Statut", get: (r) => STATUT_ORDER[r.statut] ?? 99, type: "num" },
];

export default function IssueTable({ rows, loading, onTicket, onDev, changedKeys }) {
  const [sortKey, setSortKey] = useState(null);   // null = tri "intelligent" par défaut
  const [sortDir, setSortDir] = useState("asc");
  // Pagination : en PWA/mobile on plafonne le rendu (sinon ~4759 cartes figent l'app) ; desktop inchangé.
  const isMobile = typeof window !== "undefined" && window.matchMedia && window.matchMedia("(max-width:768px)").matches;
  const [visible, setVisible] = useState(isMobile ? 40 : 100000);

  if (loading && !rows.length) return isMobile ? (
    <div className="skel-wrap" aria-busy="true" aria-label="Chargement des tickets">
      {Array.from({ length: 5 }).map((_, i) => (
        <div className="skel-card" key={i}>
          <div className="skel-row"><span className="skel skel-line sm" style={{ width: 66 }} /><span className="skel skel-line sm skel-spacer" style={{ width: 72 }} /></div>
          <div className="skel skel-line lg" style={{ width: "94%", margin: "11px 0 6px" }} />
          <div className="skel skel-line lg" style={{ width: "68%", marginBottom: 12 }} />
          <div className="skel-row"><span className="skel skel-line" style={{ width: 46 }} /><span className="skel skel-line" style={{ width: 72 }} /><span className="skel skel-line skel-spacer" style={{ width: 88 }} /></div>
        </div>
      ))}
    </div>
  ) : <div className="empty">Chargement des tickets…</div>;
  if (!rows.length) return <div className="empty">Aucun ticket pour ce filtre. Rien à traiter ici.</div>;

  const clickHeader = (key) => {
    if (sortKey === key) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(key); setSortDir("asc"); }
  };

  let sorted;
  if (!sortKey) {
    // Tri par défaut : mes tickets, puis en retard, puis statut, puis dossier.
    sorted = [...rows].sort((a, b) => {
      if (a.mine !== b.mine) return a.mine ? -1 : 1;
      if (a.enRetard !== b.enRetard) return a.enRetard ? -1 : 1;
      if ((STATUT_ORDER[a.statut] ?? 9) !== (STATUT_ORDER[b.statut] ?? 9)) return (STATUT_ORDER[a.statut] ?? 9) - (STATUT_ORDER[b.statut] ?? 9);
      return a.dossier.localeCompare(b.dossier);
    });
  } else {
    const col = COLS.find((c) => c.key === sortKey);
    const dir = sortDir === "asc" ? 1 : -1;
    sorted = [...rows].sort((a, b) => {
      const va = col.get(a), vb = col.get(b);
      let r;
      if (col.type === "num") r = (va || 0) - (vb || 0);
      else if (col.type === "date") r = String(va).localeCompare(String(vb)); // ISO -> ordre chrono
      else r = String(va).localeCompare(String(vb), "fr", { numeric: true });
      return r * dir;
    });
  }

  const arrow = (key) => {
    if (sortKey !== key) return <span className="sort-ar dim">⇅</span>;
    return <span className="sort-ar">{sortDir === "asc" ? "▲" : "▼"}</span>;
  };

  return (
    <>
    <table className="cpw-tbl">
      <thead>
        <tr>
          {COLS.map((c) => (
            <th key={c.key} className="th-sort" onClick={() => clickHeader(c.key)} title="Trier">
              {c.label} {arrow(c.key)}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {sorted.slice(0, visible).map((r) => {
          const cls = [r.mine ? "mine" : "", r.flagged ? "has-flag" : "", changedKeys && changedKeys.has(r.cle) ? "row-changed" : ""].filter(Boolean).join(" ");
          return (
            <tr key={r.cle} className={cls} onClick={() => onTicket && onTicket(r)} style={{ cursor: "pointer" }}>
              <td data-label="Clé"><span className="k">{r.cle}</span></td>
              <td data-label="Dossier"><span className="tag">{r.dossier}</span></td>
              <td data-label="Résumé">{r.flagged ? <span className="flag" title="Flaggé">🚩 </span> : null}{r.resume}{r.mine && <span className="me-badge">POUR MOI</span>}{changedKeys && changedKeys.has(r.cle) && <span className="chg-badge">MAJ</span>}{r.prog && r.prog.found && <span className="prog-chip" title={`Programme ${r.prog.name}${r.prog.lib ? " · biblio " + r.prog.lib : ""}${r.prog.srcMember ? " · source " + r.prog.srcMember : ""}`}>📦 {r.prog.lib || r.prog.name}{r.prog.srcMember ? ` / ${r.prog.srcMember}` : ""}</span>}</td>
              <td data-label="Sur le ticket">{(r.contributors && r.contributors.length) ? (
                r.contributors.map((c, idx) => (
                  <span key={c}>
                    {idx > 0 && <span className="who-sep">, </span>}
                    {onDev
                      ? <span className="assignee-link" title="Voir la fiche du développeur" onClick={(e) => { e.stopPropagation(); onDev(c); }}>{c}</span>
                      : c}
                  </span>
                ))
              ) : <span className="who-none">Non assigné</span>}</td>
              <td data-label="Échéance">{r.echeance ? <span className={r.enRetard ? "late" : ""}>{fmtDate(r.echeance)}{r.enRetard ? " ⚠" : ""}</span> : "—"}</td>
              <td data-label="Priorité">{r.priorite ? <span className="prio-cell"><span className={`prio-dot ${prioClass(r.priorite)}`} />{r.priorite}</span> : <span className="who-none">—</span>}</td>
              <td data-label="Statut"><span className={`pill ${PILL[r.statut]}`}>{r.statut}</span></td>
            </tr>
          );
        })}
      </tbody>
    </table>
    {sorted.length > visible && (
      <div className="tbl-more">
        <button className="btn-line tbl-more-btn" onClick={() => setVisible((v) => v + 60)}>
          Afficher plus de tickets
          <span className="tbl-more-cnt">{Math.min(visible, sorted.length)} / {sorted.length}</span>
        </button>
      </div>
    )}
    </>
  );
}
